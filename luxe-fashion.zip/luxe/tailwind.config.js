/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    container: {
      center: true,
      padding: "1.5rem",
      screens: { "2xl": "1360px" },
    },
    extend: {
      colors: {
        // Core luxury palette: obsidian black, ivory white, gold.
        gold: {
          50: "#fdf9ec",
          100: "#faf0cc",
          200: "#f4df94",
          300: "#eecb5c",
          400: "#e8b93a",
          500: "#d4af37", // signature gold
          600: "#b8901f",
          700: "#946c1b",
          800: "#7a561d",
          900: "#68481d",
        },
        ink: {
          50: "#f6f6f7",
          100: "#e2e2e5",
          200: "#c4c5cb",
          300: "#9fa0a9",
          400: "#797b86",
          500: "#5f606b",
          600: "#4a4b54",
          700: "#3d3e45",
          800: "#26272c",
          900: "#151619",
          950: "#0a0a0b",
        },
      },
      fontFamily: {
        // Luxury typography: a high-contrast serif display + a clean grotesque body.
        display: ['"Playfair Display"', "Georgia", "serif"],
        sans: ['"Inter"', "system-ui", "sans-serif"],
        mono: ['"Space Mono"', "monospace"],
      },
      letterSpacing: {
        luxe: "0.35em",
      },
      backgroundImage: {
        "gold-gradient":
          "linear-gradient(135deg,#f4df94 0%,#d4af37 45%,#946c1b 100%)",
        "gold-sheen":
          "linear-gradient(110deg,transparent 20%,rgba(244,223,148,0.75) 50%,transparent 80%)",
        "radial-fade":
          "radial-gradient(ellipse at center,rgba(212,175,55,0.14),transparent 60%)",
      },
      boxShadow: {
        gold: "0 10px 40px -12px rgba(212,175,55,0.55)",
        "gold-lg": "0 24px 80px -20px rgba(212,175,55,0.55)",
        glass: "0 8px 32px 0 rgba(0,0,0,0.37)",
      },
      keyframes: {
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-18px)" },
        },
        "spin-slow": {
          to: { transform: "rotate(360deg)" },
        },
        "gradient-pan": {
          "0%,100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        "pulse-glow": {
          "0%,100%": { opacity: "0.55", transform: "scale(1)" },
          "50%": { opacity: "1", transform: "scale(1.05)" },
        },
      },
      animation: {
        shimmer: "shimmer 2.4s linear infinite",
        float: "float 6s ease-in-out infinite",
        "spin-slow": "spin-slow 18s linear infinite",
        "gradient-pan": "gradient-pan 8s ease infinite",
        "pulse-glow": "pulse-glow 3.5s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
