# LUXE — Cinematic Luxury Fashion Experience

An ultra-premium, animated fashion e-commerce front end. Black · Ivory · Gold,
glassmorphism, cinematic motion, and a full 17-page shopping flow — built to feel
like an Apple keynote crossed with a couture house.

![LUXE](https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80)

---

## ✨ Highlights

- **Cinematic motion** — animated preloader, custom cursor, mouse-follow glow,
  scroll-reveal + text-reveal, parallax hero, magnetic buttons, page transitions,
  floating 3D product accessories, and a canvas particle field.
- **Real 3D** — a self-contained React Three Fiber scene (no network HDR needed).
- **Full commerce flow** — Home, Shop, Categories, Men, Women, New Arrivals,
  Best Sellers, Sale, Product Details, Wishlist, Cart, Checkout, Order Success,
  About, Contact, Blog, FAQ, plus Login / Register / Forgot Password / OTP.
- **Stateful** — cart, wishlist, coupons, recently-viewed and theme all persist
  to `localStorage` via React Context.
- **Premium UX** — dark/light mode, AI outfit stylist, quick view, image zoom,
  3D card tilt, loading skeletons, lazy images, filters, sort, price slider,
  live search, flash-sale countdown, and form validation.
- **Performance & a11y** — route-level code splitting, DPR-clamped canvases,
  `prefers-reduced-motion` support, semantic HTML, keyboard-friendly controls,
  and SEO/OpenGraph meta.

## 🧱 Tech Stack

| Concern            | Choice                                            |
| ------------------ | ------------------------------------------------- |
| Framework / build  | React 18 + Vite 5                                 |
| Styling            | Tailwind CSS 3 (custom luxury design system)      |
| Animation          | Framer Motion + GSAP                              |
| 3D                 | Three.js via @react-three/fiber + drei            |
| UI primitives      | shadcn/ui-style components (CVA + clsx + tw-merge)|
| Icons              | lucide-react                                      |
| Routing            | react-router-dom 6                                |

## 🚀 Getting Started

```bash
# 1. Install dependencies (Node 18+ recommended)
npm install

# 2. Start the dev server
npm run dev            # http://localhost:5173

# 3. Production build + local preview
npm run build
npm run preview
```

> The demo pulls placeholder imagery from Unsplash, so run it with an internet
> connection for the full visual experience. Every image degrades gracefully to a
> branded placeholder if a request fails.

## 📁 Project Structure

```
src/
├── components/
│   ├── ui/          # shadcn-style primitives (button, card, input, badge…)
│   ├── layout/      # Navbar, Footer, CartDrawer, SearchOverlay, AuthLayout
│   ├── common/      # Reusable motion + commerce building blocks
│   ├── home/        # Home-page sections (Hero, FlashSale, Reviews…)
│   └── product/     # QuickView modal
├── context/         # Theme, Cart, Wishlist providers (localStorage-backed)
├── data/            # Demo catalogue, collections, editorial content
├── hooks/           # useMediaQuery, useMousePosition, useRecentlyViewed…
├── lib/             # cn(), formatPrice(), helpers
├── pages/           # One file per route (incl. /auth)
├── App.jsx          # Routing + global cinematic layers
└── main.jsx         # Providers + bootstrap
```

## 🎨 Design System

Defined in `tailwind.config.js` + `src/index.css`:

- **Palette** — `ink` (obsidian → near-black) and `gold` scales, plus ivory.
- **Type** — Playfair Display (serif display) + Inter (body) + Space Mono (labels).
- **Surfaces** — `.glass` / `.glass-strong` glassmorphism utilities.
- **Motion** — shared easings and keyframes (`float`, `shimmer`, `gradient-pan`…).
- **Theming** — CSS variables flip between dark/light via a class on `<html>`.

## 🛒 Try These Flows

1. Add items to the bag from any grid → open the **cart drawer** → **/cart**.
2. Apply a coupon: `LUXE10`, `GOLD20`, or `FREESHIP`.
3. Complete **/checkout** (3-step, validated) → celebratory **Order Success**.
4. Sign in at **/login** with any valid-looking email + 6-char password to see
   the premium success transition.
5. Toggle **dark/light** from the navbar; heart items to build a **/wishlist**.

## 🔧 Customising

- **Products** — edit `src/data/products.js` (images, price, colours, sizes, tags).
- **Brand colours** — tweak the `gold` / `ink` scales in `tailwind.config.js`.
- **Copy & content** — `src/data/collections.js` and `src/data/content.js`.
- **3D hero** — swap shapes/materials in `src/components/home/Hero3D.jsx`.

## 📝 Notes

This is a front-end demo: authentication, payment and checkout are simulated
client-side (no real network calls or charges). Wire the forms in `pages/auth/*`
and `pages/Checkout.jsx` to your backend when you're ready to go live.

---

Crafted with obsession for detail. © LUXE Fashion House.
