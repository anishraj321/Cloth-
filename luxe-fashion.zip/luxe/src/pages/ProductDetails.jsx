import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart,
  ShoppingBag,
  Truck,
  RefreshCw,
  ShieldCheck,
  Minus,
  Plus,
  Check,
  ChevronRight,
} from "lucide-react";
import { getProductById, getRelated } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { LazyImage } from "@/components/common/LazyImage";
import { Rating } from "@/components/common/Rating";
import { SectionHeading } from "@/components/common/SectionHeading";
import { ProductGrid } from "@/components/common/ProductGrid";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";
import { cn, formatPrice } from "@/lib/utils";
import NotFound from "./NotFound";

const perks = [
  { icon: Truck, label: "Free express shipping" },
  { icon: RefreshCw, label: "30-day free returns" },
  { icon: ShieldCheck, label: "Lifetime authenticity" },
];

export default function ProductDetails() {
  const { id } = useParams();
  const product = getProductById(id);
  const { addItem } = useCart();
  const { has, toggle } = useWishlist();
  const { ids, record } = useRecentlyViewed();

  const [activeImg, setActiveImg] = useState(0);
  const [size, setSize] = useState(null);
  const [color, setColor] = useState(null);
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState("details");
  const [added, setAdded] = useState(false);
  const [zoom, setZoom] = useState({ active: false, x: 50, y: 50 });

  useEffect(() => {
    if (product) {
      record(product.id);
      setActiveImg(0);
      setSize(null);
      setColor(product.colors[0]?.name || null);
      setQty(1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const related = useMemo(() => (product ? getRelated(product) : []), [product]);
  const recent = useMemo(
    () => ids.filter((x) => x !== id).map(getProductById).filter(Boolean).slice(0, 4),
    [ids, id]
  );

  if (!product) return <NotFound />;

  const price = product.salePrice || product.price;

  const handleAdd = () => {
    addItem(product, { size: size || product.sizes[0], color: color || product.colors[0]?.name, qty });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <>
      <PageHeader
        title=""
        crumbs={[
          { label: "Shop", to: "/shop" },
          { label: product.category === "men" ? "Men" : "Women", to: `/${product.category}` },
          { label: product.name },
        ]}
      />

      <section className="container -mt-6 pb-24">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Gallery */}
          <div className="flex flex-col-reverse gap-4 md:flex-row">
            <div className="flex gap-3 md:flex-col">
              {product.images.map((src, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(i)}
                  className={cn(
                    "h-20 w-16 overflow-hidden rounded-xl border-2 transition-colors md:h-24 md:w-20",
                    activeImg === i ? "border-gold-500" : "border-transparent opacity-60 hover:opacity-100"
                  )}
                >
                  <LazyImage src={src} alt="" className="h-full w-full" />
                </button>
              ))}
            </div>

            <div
              className="relative flex-1 overflow-hidden rounded-3xl"
              onMouseMove={(e) => {
                const r = e.currentTarget.getBoundingClientRect();
                setZoom({
                  active: true,
                  x: ((e.clientX - r.left) / r.width) * 100,
                  y: ((e.clientY - r.top) / r.height) * 100,
                });
              }}
              onMouseLeave={() => setZoom((z) => ({ ...z, active: false }))}
            >
              <AnimatePresence mode="wait">
                <motion.img
                  key={activeImg}
                  src={product.images[activeImg]}
                  alt={product.name}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                  className="aspect-[3/4] w-full object-cover transition-transform duration-200"
                  style={{
                    transformOrigin: `${zoom.x}% ${zoom.y}%`,
                    transform: zoom.active ? "scale(1.6)" : "scale(1)",
                  }}
                />
              </AnimatePresence>
              {product.badge && (
                <Badge variant={product.salePrice ? "sale" : "gold"} className="absolute left-4 top-4">
                  {product.badge}
                </Badge>
              )}
            </div>
          </div>

          {/* Details */}
          <div className="lg:pt-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <p className="eyebrow">{product.subcategory}</p>
              <h1 className="mt-2 font-display text-4xl md:text-5xl">{product.name}</h1>
              <div className="mt-3 flex items-center gap-4">
                <Rating value={product.rating} count={product.reviewsCount} />
              </div>

              <div className="mt-6 flex items-baseline gap-3">
                <motion.span
                  key={price}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="font-display text-3xl text-gold-gradient"
                >
                  {formatPrice(price)}
                </motion.span>
                {product.salePrice && (
                  <span className="text-lg text-ink-400 line-through">
                    {formatPrice(product.price)}
                  </span>
                )}
              </div>

              <p className="mt-6 leading-relaxed text-ink-300">{product.description}</p>

              {/* Colours */}
              <div className="mt-8">
                <p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-ink-400">
                  Colour — <span className="text-white">{color}</span>
                </p>
                <div className="flex gap-3">
                  {product.colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setColor(c.name)}
                      title={c.name}
                      style={{ background: c.hex }}
                      className={cn(
                        "h-9 w-9 rounded-full border-2 transition-transform hover:scale-110",
                        color === c.name ? "border-gold-500 ring-2 ring-gold-500/30" : "border-white/20"
                      )}
                    />
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div className="mt-6">
                <div className="mb-3 flex items-center justify-between">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-ink-400">
                    Size
                  </p>
                  <button className="text-xs text-gold-500 hover:underline">Size guide</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={cn(
                        "h-11 min-w-[3rem] rounded-xl border px-4 text-sm transition-all",
                        size === s
                          ? "border-gold-500 bg-gold-500/10 text-gold-500"
                          : "border-white/15 hover:border-white/40"
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity + actions */}
              <div className="mt-8 flex items-center gap-4">
                <div className="flex items-center gap-4 rounded-full border border-white/15 px-4 py-3">
                  <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity">
                    <Minus size={16} />
                  </button>
                  <span className="w-5 text-center tabular-nums">{qty}</span>
                  <button onClick={() => setQty((q) => q + 1)} aria-label="Increase quantity">
                    <Plus size={16} />
                  </button>
                </div>
                <Button className="flex-1" size="lg" onClick={handleAdd}>
                  <AnimatePresence mode="wait">
                    {added ? (
                      <motion.span key="ok" initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2">
                        <Check size={18} /> Added
                      </motion.span>
                    ) : (
                      <motion.span key="add" className="flex items-center gap-2">
                        <ShoppingBag size={18} /> Add to Bag
                      </motion.span>
                    )}
                  </AnimatePresence>
                </Button>
                <Button
                  variant="glass"
                  size="icon"
                  className="h-14 w-14"
                  onClick={() => toggle(product.id)}
                  aria-label="Wishlist"
                >
                  <Heart size={20} className={has(product.id) ? "fill-gold-500 text-gold-500" : ""} />
                </Button>
              </div>

              {/* Perks */}
              <div className="mt-8 grid grid-cols-3 gap-3">
                {perks.map((p) => (
                  <div key={p.label} className="flex flex-col items-center gap-2 rounded-2xl glass p-4 text-center">
                    <p.icon size={20} className="text-gold-500" />
                    <span className="text-xs text-ink-300">{p.label}</span>
                  </div>
                ))}
              </div>

              {/* Tabs */}
              <div className="mt-10">
                <div className="flex gap-6 border-b border-white/10">
                  {["details", "shipping"].map((t) => (
                    <button
                      key={t}
                      onClick={() => setTab(t)}
                      className={cn(
                        "relative pb-3 text-sm capitalize transition-colors",
                        tab === t ? "text-gold-500" : "text-ink-400 hover:text-white"
                      )}
                    >
                      {t}
                      {tab === t && (
                        <motion.span layoutId="tab-underline" className="absolute inset-x-0 -bottom-px h-0.5 bg-gold-gradient" />
                      )}
                    </button>
                  ))}
                </div>
                <div className="pt-5 text-sm leading-relaxed text-ink-300">
                  {tab === "details" ? (
                    <ul className="space-y-2">
                      {product.details.map((d) => (
                        <li key={d} className="flex items-center gap-2">
                          <span className="h-1 w-1 rounded-full bg-gold-500" />
                          {d}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p>
                      Complimentary express shipping on orders over $500, delivered in
                      2–4 business days worldwide. Enjoy 30 days of free returns — no
                      questions asked.
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Related */}
        <div className="mt-28">
          <SectionHeading eyebrow="Complete the Look" title="You May Also Like" />
          <div className="mt-12">
            <ProductGrid products={related} columns={4} />
          </div>
        </div>

        {/* Recently viewed */}
        {recent.length > 0 && (
          <div className="mt-24">
            <div className="mb-8 flex items-center justify-between">
              <h3 className="font-display text-2xl">Recently Viewed</h3>
              <Link to="/shop" className="inline-flex items-center gap-1 text-sm text-gold-500">
                All products <ChevronRight size={14} />
              </Link>
            </div>
            <ProductGrid products={recent} columns={4} />
          </div>
        )}
      </section>
    </>
  );
}
