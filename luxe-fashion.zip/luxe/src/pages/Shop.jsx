import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { products } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { CollectionView } from "@/components/common/CollectionView";

/** Full catalogue with optional ?cat= pre-filter from category links. */
export default function Shop() {
  const [params] = useSearchParams();
  const cat = params.get("cat");
  const [loading, setLoading] = useState(true);

  // Simulate a brief fetch so the loading skeletons are demonstrable.
  useEffect(() => {
    setLoading(true);
    const id = setTimeout(() => setLoading(false), 450);
    return () => clearTimeout(id);
  }, [cat]);

  const list = useMemo(
    () => (cat ? products.filter((p) => p.subcategory === cat) : products),
    [cat]
  );

  return (
    <>
      <PageHeader
        title={cat || "The Boutique"}
        subtitle="Every piece, one place. Sculptural tailoring, rare fabrics, quiet luxury."
        crumbs={[{ label: "Shop" }]}
      />
      <CollectionView products={list} loading={loading} />
    </>
  );
}
