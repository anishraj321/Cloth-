import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Check, CreditCard, Truck, ClipboardCheck, Lock, ChevronLeft } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { PageHeader } from "@/components/common/PageHeader";
import { LazyImage } from "@/components/common/LazyImage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatPrice } from "@/lib/utils";

const steps = [
  { id: "shipping", label: "Shipping", icon: Truck },
  { id: "payment", label: "Payment", icon: CreditCard },
  { id: "review", label: "Review", icon: ClipboardCheck },
];

/** Field with inline validation + floating error. */
function Field({ label, error, className = "", ...props }) {
  return (
    <div className={className}>
      <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-ink-400">
        {label}
      </label>
      <Input aria-invalid={Boolean(error)} className={error ? "border-red-400/70" : ""} {...props} />
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}

export default function Checkout() {
  const { items, totals, clear } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    email: "", firstName: "", lastName: "", address: "", city: "", zip: "", country: "United States",
    card: "", expiry: "", cvc: "", nameOnCard: "",
  });
  const [errors, setErrors] = useState({});

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validateShipping = () => {
    const e = {};
    if (!form.email.includes("@")) e.email = "Enter a valid email";
    if (!form.firstName) e.firstName = "Required";
    if (!form.lastName) e.lastName = "Required";
    if (!form.address) e.address = "Required";
    if (!form.city) e.city = "Required";
    if (!form.zip) e.zip = "Required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };
  const validatePayment = () => {
    const e = {};
    if (form.card.replace(/\s/g, "").length < 15) e.card = "Enter a valid card number";
    if (!/^\d{2}\/\d{2}$/.test(form.expiry)) e.expiry = "MM/YY";
    if (form.cvc.length < 3) e.cvc = "3–4 digits";
    if (!form.nameOnCard) e.nameOnCard = "Required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (step === 0 && !validateShipping()) return;
    if (step === 1 && !validatePayment()) return;
    setStep((s) => Math.min(2, s + 1));
  };

  const placeOrder = () => {
    const orderId = "LX" + Math.random().toString(36).slice(2, 8).toUpperCase();
    clear();
    navigate("/order-success", { state: { orderId, email: form.email } });
  };

  if (items.length === 0) {
    return (
      <>
        <PageHeader title="Checkout" crumbs={[{ label: "Checkout" }]} />
        <div className="container grid place-items-center pb-24">
          <div className="rounded-3xl glass px-10 py-20 text-center">
            <p className="font-display text-2xl">Your bag is empty</p>
            <Link to="/shop" className="mt-6 inline-block">
              <Button>Browse the collection</Button>
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader title="Checkout" crumbs={[{ label: "Cart", to: "/cart" }, { label: "Checkout" }]} />
      <section className="container pb-24">
        {/* Stepper */}
        <div className="mx-auto mb-12 flex max-w-xl items-center justify-between">
          {steps.map((s, i) => (
            <div key={s.id} className="flex flex-1 items-center last:flex-none">
              <div className="flex flex-col items-center gap-2">
                <div
                  className={`grid h-11 w-11 place-items-center rounded-full border transition-all ${
                    i <= step
                      ? "border-gold-500 bg-gold-gradient text-ink-950"
                      : "border-white/20 text-ink-400"
                  }`}
                >
                  {i < step ? <Check size={18} /> : <s.icon size={18} />}
                </div>
                <span className={`text-xs ${i <= step ? "text-gold-500" : "text-ink-400"}`}>{s.label}</span>
              </div>
              {i < steps.length - 1 && (
                <div className="mx-2 h-px flex-1 bg-white/15">
                  <div className={`h-full bg-gold-gradient transition-all duration-500 ${i < step ? "w-full" : "w-0"}`} />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
          <div className="rounded-3xl glass p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.4 }}
              >
                {step === 0 && (
                  <div className="space-y-5">
                    <h3 className="font-display text-2xl">Shipping details</h3>
                    <Field label="Email" type="email" value={form.email} onChange={set("email")} error={errors.email} placeholder="your@email.com" />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="First name" value={form.firstName} onChange={set("firstName")} error={errors.firstName} />
                      <Field label="Last name" value={form.lastName} onChange={set("lastName")} error={errors.lastName} />
                    </div>
                    <Field label="Address" value={form.address} onChange={set("address")} error={errors.address} />
                    <div className="grid gap-4 sm:grid-cols-3">
                      <Field label="City" value={form.city} onChange={set("city")} error={errors.city} />
                      <Field label="ZIP" value={form.zip} onChange={set("zip")} error={errors.zip} />
                      <div>
                        <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-ink-400">Country</label>
                        <select value={form.country} onChange={set("country")} className="h-12 w-full rounded-xl border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-gold-500/60">
                          {["United States", "United Kingdom", "France", "Japan", "UAE", "India"].map((c) => (
                            <option key={c} className="bg-ink-900">{c}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {step === 1 && (
                  <div className="space-y-5">
                    <h3 className="font-display text-2xl">Payment</h3>
                    <div className="flex items-center gap-2 rounded-xl bg-gold-500/10 px-4 py-3 text-xs text-gold-500">
                      <Lock size={14} /> Encrypted & secure. This is a demo — no real charge is made.
                    </div>
                    <Field label="Name on card" value={form.nameOnCard} onChange={set("nameOnCard")} error={errors.nameOnCard} />
                    <Field
                      label="Card number"
                      value={form.card}
                      onChange={(e) => {
                        const digits = e.target.value.replace(/\D/g, "").slice(0, 16);
                        setForm((f) => ({ ...f, card: digits.replace(/(.{4})/g, "$1 ").trim() }));
                      }}
                      error={errors.card}
                      placeholder="4242 4242 4242 4242"
                    />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="Expiry"
                        value={form.expiry}
                        onChange={(e) => {
                          let v = e.target.value.replace(/\D/g, "").slice(0, 4);
                          if (v.length >= 3) v = v.slice(0, 2) + "/" + v.slice(2);
                          setForm((f) => ({ ...f, expiry: v }));
                        }}
                        error={errors.expiry}
                        placeholder="MM/YY"
                      />
                      <Field label="CVC" value={form.cvc} onChange={(e) => setForm((f) => ({ ...f, cvc: e.target.value.replace(/\D/g, "").slice(0, 4) }))} error={errors.cvc} placeholder="123" />
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-5">
                    <h3 className="font-display text-2xl">Review your order</h3>
                    <div className="rounded-2xl border border-white/10 p-5">
                      <p className="font-mono text-[10px] uppercase tracking-widest text-ink-400">Shipping to</p>
                      <p className="mt-1">{form.firstName} {form.lastName}</p>
                      <p className="text-sm text-ink-300">{form.address}, {form.city} {form.zip}, {form.country}</p>
                      <p className="text-sm text-ink-300">{form.email}</p>
                    </div>
                    <div className="rounded-2xl border border-white/10 p-5">
                      <p className="font-mono text-[10px] uppercase tracking-widest text-ink-400">Paying with</p>
                      <p className="mt-1 flex items-center gap-2"><CreditCard size={16} /> •••• {form.card.slice(-4) || "0000"}</p>
                    </div>
                    <div className="space-y-3">
                      {items.map((l) => (
                        <div key={l.key} className="flex items-center gap-3">
                          <LazyImage src={l.image} alt="" className="h-14 w-12 rounded-lg" />
                          <div className="flex-1">
                            <p className="text-sm">{l.name}</p>
                            <p className="text-xs text-ink-400">Qty {l.qty}</p>
                          </div>
                          <span className="text-sm text-gold-500">{formatPrice(l.price * l.qty)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="mt-8 flex items-center justify-between">
              {step > 0 ? (
                <button onClick={() => setStep((s) => s - 1)} className="inline-flex items-center gap-1 text-sm text-ink-400 hover:text-white">
                  <ChevronLeft size={16} /> Back
                </button>
              ) : (
                <Link to="/cart" className="inline-flex items-center gap-1 text-sm text-ink-400 hover:text-white">
                  <ChevronLeft size={16} /> Back to bag
                </Link>
              )}
              {step < 2 ? (
                <Button onClick={next}>Continue</Button>
              ) : (
                <Button onClick={placeOrder} size="lg">
                  <Lock size={16} /> Place Order · {formatPrice(totals.total)}
                </Button>
              )}
            </div>
          </div>

          {/* Summary */}
          <aside className="lg:sticky lg:top-28 lg:h-fit">
            <div className="space-y-4 rounded-2xl glass-strong p-6">
              <h3 className="font-display text-xl">Summary</h3>
              <div className="max-h-64 space-y-3 overflow-y-auto no-scrollbar">
                {items.map((l) => (
                  <div key={l.key} className="flex items-center gap-3">
                    <div className="relative">
                      <LazyImage src={l.image} alt="" className="h-14 w-12 rounded-lg" />
                      <span className="absolute -right-2 -top-2 grid h-5 w-5 place-items-center rounded-full bg-gold-gradient text-[10px] font-bold text-ink-950">{l.qty}</span>
                    </div>
                    <p className="flex-1 text-sm">{l.name}</p>
                    <span className="text-sm text-gold-500">{formatPrice(l.price * l.qty)}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-2 border-t border-white/10 pt-4 text-sm">
                <div className="flex justify-between text-ink-400"><span>Subtotal</span><span>{formatPrice(totals.subtotal)}</span></div>
                {totals.discount > 0 && <div className="flex justify-between text-gold-500"><span>Discount</span><span>- {formatPrice(totals.discount)}</span></div>}
                <div className="flex justify-between text-ink-400"><span>Shipping</span><span>{totals.shipping === 0 ? "Free" : formatPrice(totals.shipping)}</span></div>
                <div className="flex justify-between text-ink-400"><span>Tax</span><span>{formatPrice(totals.tax)}</span></div>
                <div className="flex justify-between border-t border-white/10 pt-3 font-display text-lg"><span>Total</span><span className="text-gold-gradient">{formatPrice(totals.total)}</span></div>
              </div>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
