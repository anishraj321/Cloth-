import { getByCategory } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { CollectionView } from "@/components/common/CollectionView";

export default function Men() {
  return (
    <>
      <PageHeader
        title="Men"
        subtitle="Precision tailoring and uncompromising cloth for the modern man."
        crumbs={[{ label: "Men" }]}
      />
      <CollectionView products={getByCategory("men")} />
    </>
  );
}
