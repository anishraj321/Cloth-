import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Minus, Plus, Trash2, Tag, ArrowRight, ShoppingBag, Check, Truck } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { PageHeader } from "@/components/common/PageHeader";
import { LazyImage } from "@/components/common/LazyImage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatPrice } from "@/lib/utils";

export default function Cart() {
  const { items, setQty, removeItem, totals, coupon, applyCoupon, removeCoupon } = useCart();
  const [code, setCode] = useState("");
  const [feedback, setFeedback] = useState(null);
  const [country, setCountry] = useState("United States");

  const handleCoupon = () => {
    const res = applyCoupon(code);
    setFeedback(res);
    if (res.ok) setCode("");
  };

  if (items.length === 0) {
    return (
      <>
        <PageHeader title="Your Bag" crumbs={[{ label: "Cart" }]} />
        <section className="container pb-24">
          <div className="grid place-items-center rounded-3xl glass py-28 text-center">
            <div className="grid h-20 w-20 place-items-center rounded-full glass">
              <ShoppingBag className="text-gold-500" />
            </div>
            <p className="mt-6 font-display text-2xl">Your bag is empty</p>
            <p className="mt-2 text-ink-400">Let's find something worthy of it.</p>
            <Link to="/shop" className="mt-6">
              <Button>Start shopping</Button>
            </Link>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <PageHeader title="Your Bag" subtitle={`${items.length} pieces ready for checkout.`} crumbs={[{ label: "Cart" }]} />
      <section className="container pb-24">
        <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
          {/* Line items */}
          <div className="space-y-4">
            <AnimatePresence>
              {items.map((line) => (
                <motion.div
                  key={line.key}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  className="flex gap-5 rounded-2xl glass p-4"
                >
                  <LazyImage src={line.image} alt={line.name} className="h-32 w-28 shrink-0 rounded-xl" />
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-display text-lg">{line.name}</p>
                        <p className="text-xs text-ink-400">
                          {[line.size, line.color].filter(Boolean).join(" · ")}
                        </p>
                      </div>
                      <button onClick={() => removeItem(line.key)} aria-label="Remove item">
                        <Trash2 size={18} className="text-ink-400 transition-colors hover:text-white" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="flex items-center gap-4 rounded-full border border-white/10 px-3 py-2">
                        <button onClick={() => setQty(line.key, line.qty - 1)} aria-label="Decrease">
                          <Minus size={14} />
                        </button>
                        <span className="w-5 text-center text-sm tabular-nums">{line.qty}</span>
                        <button onClick={() => setQty(line.key, line.qty + 1)} aria-label="Increase">
                          <Plus size={14} />
                        </button>
                      </div>
                      <span className="font-display text-lg text-gold-gradient">
                        {formatPrice(line.price * line.qty)}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Summary */}
          <aside className="lg:sticky lg:top-28 lg:h-fit">
            <div className="space-y-6 rounded-2xl glass-strong p-6">
              <h3 className="font-display text-2xl">Order Summary</h3>

              {/* Coupon */}
              <div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
                    <Input
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder="Coupon code"
                      className="pl-9"
                    />
                  </div>
                  <Button variant="outline" onClick={handleCoupon}>Apply</Button>
                </div>
                {feedback && (
                  <p className={`mt-2 text-xs ${feedback.ok ? "text-gold-500" : "text-red-400"}`}>
                    {feedback.message}
                  </p>
                )}
                {coupon && (
                  <div className="mt-2 flex items-center justify-between rounded-lg bg-gold-500/10 px-3 py-2 text-xs text-gold-500">
                    <span className="flex items-center gap-1"><Check size={13} /> {coupon} applied</span>
                    <button onClick={removeCoupon} className="underline">Remove</button>
                  </div>
                )}
                <p className="mt-2 text-[11px] text-ink-500">Try: LUXE10, GOLD20, FREESHIP</p>
              </div>

              {/* Shipping estimate */}
              <div>
                <label className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-ink-400">
                  <Truck size={13} /> Ship to
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="h-11 w-full rounded-xl border border-white/10 bg-white/5 px-3 text-sm outline-none focus:border-gold-500/60"
                >
                  {["United States", "United Kingdom", "France", "Japan", "UAE", "India"].map((c) => (
                    <option key={c} className="bg-ink-900">{c}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-3 border-t border-white/10 pt-4 text-sm">
                <Row label="Subtotal" value={formatPrice(totals.subtotal)} />
                {totals.discount > 0 && (
                  <Row label="Discount" value={`- ${formatPrice(totals.discount)}`} accent />
                )}
                <Row
                  label="Shipping"
                  value={totals.shipping === 0 ? "Free" : formatPrice(totals.shipping)}
                />
                <Row label="Estimated tax" value={formatPrice(totals.tax)} />
                <div className="flex justify-between border-t border-white/10 pt-4 font-display text-xl">
                  <span>Total</span>
                  <span className="text-gold-gradient">{formatPrice(totals.total)}</span>
                </div>
              </div>

              <Link to="/checkout">
                <Button className="w-full" size="lg">
                  Secure Checkout <ArrowRight size={18} />
                </Button>
              </Link>
              <Link to="/shop" className="block text-center text-sm text-ink-400 hover:text-white">
                Continue shopping
              </Link>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}

function Row({ label, value, accent }) {
  return (
    <div className="flex justify-between">
      <span className="text-ink-400">{label}</span>
      <span className={accent ? "text-gold-500" : ""}>{value}</span>
    </div>
  );
}
