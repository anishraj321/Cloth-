import { Hero } from "@/components/home/Hero";
import { BrandPartners } from "@/components/home/BrandPartners";
import { FeaturedCollections } from "@/components/home/FeaturedCollections";
import { TrendingProducts } from "@/components/home/TrendingProducts";
import { NewArrivalsStrip } from "@/components/home/NewArrivalsStrip";
import { FlashSale } from "@/components/home/FlashSale";
import { AIOutfit } from "@/components/home/AIOutfit";
import { Reviews } from "@/components/home/Reviews";
import { InstagramGallery } from "@/components/home/InstagramGallery";

/** The LUXE home page — a cinematic scroll through the full brand story. */
export default function Home() {
  return (
    <>
      <Hero />
      <BrandPartners />
      <FeaturedCollections />
      <TrendingProducts />
      <FlashSale />
      <NewArrivalsStrip />
      <AIOutfit />
      <Reviews />
      <InstagramGallery />
    </>
  );
}
