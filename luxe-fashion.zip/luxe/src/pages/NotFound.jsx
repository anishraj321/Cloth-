import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ParticleBackground } from "@/components/common/ParticleBackground";
import { MagneticButton } from "@/components/common/MagneticButton";

export default function NotFound() {
  return (
    <section className="relative grid min-h-screen place-items-center overflow-hidden">
      <ParticleBackground density={50} />
      <div className="relative z-10 text-center">
        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="font-display text-[8rem] font-bold leading-none text-gold-gradient md:text-[14rem]"
        >
          404
        </motion.h1>
        <p className="mt-4 font-display text-2xl">This page slipped off the runway.</p>
        <p className="mt-2 text-ink-400">The look you're after doesn't exist — or has sold out.</p>
        <MagneticButton className="mt-8">
          <Link to="/">
            <Button size="lg">
              <Home size={18} /> Back to Home
            </Button>
          </Link>
        </MagneticButton>
      </div>
    </section>
  );
}
