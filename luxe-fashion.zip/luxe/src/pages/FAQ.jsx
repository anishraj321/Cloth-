import { Link } from "react-router-dom";
import { faqs } from "@/data/content";
import { PageHeader } from "@/components/common/PageHeader";
import { Accordion, AccordionItem } from "@/components/ui/accordion";
import { Reveal } from "@/components/common/Reveal";
import { Button } from "@/components/ui/button";

export default function FAQ() {
  return (
    <>
      <PageHeader
        title="Help & FAQ"
        subtitle="Answers to the questions we hear most. Still stuck? Our concierge is a message away."
        crumbs={[{ label: "FAQ" }]}
      />

      <section className="container pb-24">
        <div className="mx-auto max-w-3xl space-y-12">
          {faqs.map((group, gi) => (
            <Reveal key={group.category} index={gi}>
              <div>
                <h2 className="mb-2 font-mono text-xs uppercase tracking-luxe text-gold-500">
                  {group.category}
                </h2>
                <Accordion>
                  {group.items.map((item, i) => (
                    <AccordionItem key={i} value={`${gi}-${i}`} question={item.q}>
                      {item.a}
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </Reveal>
          ))}

          <Reveal>
            <div className="rounded-3xl glass-strong p-10 text-center">
              <h3 className="font-display text-2xl">Still have questions?</h3>
              <p className="mt-2 text-ink-300">Our concierge team is here to help, one-to-one.</p>
              <Link to="/contact" className="mt-6 inline-block">
                <Button>Contact concierge</Button>
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
