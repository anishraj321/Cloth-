import { getByTag } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { CollectionView } from "@/components/common/CollectionView";

export default function Sale() {
  return (
    <>
      <PageHeader
        title="The Gilded Sale"
        subtitle="Rare markdowns on coveted pieces. When they're gone, they're gone."
        crumbs={[{ label: "Sale" }]}
      />
      <CollectionView products={getByTag("sale")} />
    </>
  );
}
