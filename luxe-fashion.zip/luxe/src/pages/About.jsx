import { motion } from "framer-motion";
import { Gem, Leaf, Scissors, Globe } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { SectionHeading } from "@/components/common/SectionHeading";
import { LazyImage } from "@/components/common/LazyImage";
import { Reveal } from "@/components/common/Reveal";

const values = [
  { icon: Scissors, title: "Master Craft", text: "Every seam is placed by artisans with decades at the bench." },
  { icon: Gem, title: "Rare Materials", text: "Grade-A cashmere, Italian gabardine, mulberry silk — nothing less." },
  { icon: Leaf, title: "Conscious", text: "Traceable fibres and carbon-neutral delivery, always." },
  { icon: Globe, title: "Worldwide", text: "Dressing tastemakers across 120+ countries." },
];

const stats = [
  ["2014", "Founded"],
  ["120+", "Countries"],
  ["48", "Artisans"],
  ["4.9★", "Rated"],
];

const img = (id) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=900&q=80`;

export default function About() {
  return (
    <>
      <PageHeader
        title="Our Story"
        subtitle="LUXE was born from a single conviction: that clothing can be architecture for the body — cinematic, precise, and quietly powerful."
        crumbs={[{ label: "About" }]}
      />

      {/* Story */}
      <section className="container py-16">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <Reveal direction="right">
            <div className="relative overflow-hidden rounded-3xl">
              <LazyImage src={img("1441984904996-e0b6ba687e04")} alt="The LUXE atelier" className="aspect-[4/5]" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/50 to-transparent" />
            </div>
          </Reveal>
          <div>
            <SectionHeading
              align="left"
              eyebrow="The Atelier"
              title="Where obsession meets restraint"
            />
            <div className="mt-6 space-y-4 text-ink-300">
              <p>
                From a small studio in Florence, we set out to reject fast fashion's
                noise. We believed a wardrobe should be edited, intentional, and built
                to outlast trends — pieces you reach for a decade from now.
              </p>
              <p>
                Today, LUXE dresses a global community of people who understand that
                true luxury whispers. Each collection is a story told in cloth, light,
                and the confidence of the person wearing it.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-white/10 py-16">
        <div className="container grid grid-cols-2 gap-8 text-center md:grid-cols-4">
          {stats.map(([n, l], i) => (
            <Reveal key={l} index={i}>
              <p className="font-display text-4xl text-gold-gradient md:text-5xl">{n}</p>
              <p className="mt-2 text-xs uppercase tracking-widest text-ink-400">{l}</p>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Values */}
      <section className="container py-24">
        <SectionHeading eyebrow="Our Values" title="What We Stand For" />
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v, i) => (
            <Reveal key={v.title} index={i}>
              <motion.div
                whileHover={{ y: -6 }}
                className="h-full rounded-2xl glass p-7"
              >
                <div className="grid h-12 w-12 place-items-center rounded-xl bg-gold-500/10 text-gold-500">
                  <v.icon size={22} />
                </div>
                <h3 className="mt-5 font-display text-xl">{v.title}</h3>
                <p className="mt-2 text-sm text-ink-300">{v.text}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
