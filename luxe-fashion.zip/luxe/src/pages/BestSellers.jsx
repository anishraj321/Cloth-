import { getByTag } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { CollectionView } from "@/components/common/CollectionView";

export default function BestSellers() {
  return (
    <>
      <PageHeader
        title="Best Sellers"
        subtitle="The icons. The pieces our community returns to, season after season."
        crumbs={[{ label: "Best Sellers" }]}
      />
      <CollectionView products={getByTag("bestseller")} />
    </>
  );
}
