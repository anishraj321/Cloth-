import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Check, Package, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MagneticButton } from "@/components/common/MagneticButton";
import { seededRandom } from "@/lib/utils";

/** A small burst of gold confetti celebrating a completed order. */
function Confetti() {
  const pieces = Array.from({ length: 60 }, (_, i) => ({
    id: i,
    x: seededRandom(i + 1) * 100,
    delay: seededRandom(i + 2) * 0.6,
    rotate: seededRandom(i + 3) * 360,
    size: 5 + seededRandom(i + 4) * 8,
    color: ["#d4af37", "#f4df94", "#ffffff", "#946c1b"][i % 4],
  }));
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {pieces.map((p) => (
        <motion.span
          key={p.id}
          className="absolute top-0"
          style={{ left: `${p.x}%`, width: p.size, height: p.size, background: p.color, borderRadius: 2 }}
          initial={{ y: -40, opacity: 0, rotate: 0 }}
          animate={{ y: "110vh", opacity: [0, 1, 1, 0], rotate: p.rotate }}
          transition={{ duration: 3 + p.delay, delay: p.delay, ease: "easeIn" }}
        />
      ))}
    </div>
  );
}

export default function OrderSuccess() {
  const { state } = useLocation();
  const orderId = state?.orderId || "LX8F2K9A";
  const email = state?.email || "you";
  const [show, setShow] = useState(false);
  useEffect(() => setShow(true), []);

  return (
    <section className="relative grid min-h-screen place-items-center overflow-hidden px-6 pt-24">
      {show && <Confetti />}
      <div className="pointer-events-none absolute inset-0 bg-radial-fade" />
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-lg rounded-3xl glass-strong p-10 text-center"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 12, delay: 0.2 }}
          className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-gold-gradient text-ink-950 shadow-gold-lg"
        >
          <Check size={40} strokeWidth={3} />
        </motion.div>

        <h1 className="mt-8 font-display text-4xl">Order confirmed</h1>
        <p className="mt-3 text-ink-300">
          Thank you. A confirmation is on its way to <span className="text-gold-500">{email}</span>.
        </p>

        <div className="mt-8 flex items-center justify-between rounded-2xl border border-white/10 p-5 text-left">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-ink-400">Order number</p>
            <p className="font-display text-xl text-gold-gradient">{orderId}</p>
          </div>
          <div className="grid h-12 w-12 place-items-center rounded-full glass">
            <Package className="text-gold-500" />
          </div>
        </div>

        <p className="mt-6 text-sm text-ink-400">
          Estimated delivery in 2–4 business days. You'll receive a live tracking link shortly.
        </p>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <MagneticButton className="flex-1">
            <Link to="/shop" className="block">
              <Button className="w-full">
                Continue shopping <ArrowRight size={16} />
              </Button>
            </Link>
          </MagneticButton>
          <Link to="/" className="flex-1">
            <Button variant="glass" className="w-full">Back home</Button>
          </Link>
        </div>
      </motion.div>
    </section>
  );
}
