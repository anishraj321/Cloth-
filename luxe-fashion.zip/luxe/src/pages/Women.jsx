import { getByCategory } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { CollectionView } from "@/components/common/CollectionView";

export default function Women() {
  return (
    <>
      <PageHeader
        title="Women"
        subtitle="Sculptural silhouettes and liquid fabrics, designed to command the room."
        crumbs={[{ label: "Women" }]}
      />
      <CollectionView products={getByCategory("women")} />
    </>
  );
}
