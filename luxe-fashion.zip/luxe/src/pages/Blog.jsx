import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowUpRight, Clock } from "lucide-react";
import { posts } from "@/data/content";
import { PageHeader } from "@/components/common/PageHeader";
import { LazyImage } from "@/components/common/LazyImage";
import { Badge } from "@/components/ui/badge";
import { Reveal } from "@/components/common/Reveal";

export default function Blog() {
  const [feature, ...rest] = posts;
  return (
    <>
      <PageHeader
        title="The Journal"
        subtitle="Craft, culture, and the stories behind the collections."
        crumbs={[{ label: "Journal" }]}
      />

      <section className="container pb-24">
        {/* Featured post */}
        <Reveal>
          <Link to="/blog" className="group relative block overflow-hidden rounded-3xl">
            <LazyImage
              src={feature.image}
              alt={feature.title}
              className="aspect-[16/9] md:aspect-[21/9]"
              imgClassName="transition-transform duration-[1200ms] group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/30 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-8 md:p-12">
              <Badge variant="gold">{feature.category}</Badge>
              <h2 className="mt-4 max-w-2xl font-display text-3xl md:text-5xl">{feature.title}</h2>
              <p className="mt-3 max-w-xl text-ink-300">{feature.excerpt}</p>
              <div className="mt-4 flex items-center gap-4 text-xs text-ink-400">
                <span>{feature.author}</span>
                <span>·</span>
                <span>{feature.date}</span>
                <span className="flex items-center gap-1"><Clock size={12} /> {feature.readTime}</span>
              </div>
            </div>
          </Link>
        </Reveal>

        {/* Grid */}
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {rest.map((post, i) => (
            <Reveal key={post.id} index={i}>
              <motion.article whileHover={{ y: -6 }} className="group h-full overflow-hidden rounded-2xl glass">
                <Link to="/blog">
                  <div className="relative overflow-hidden">
                    <LazyImage
                      src={post.image}
                      alt={post.title}
                      className="aspect-[4/3]"
                      imgClassName="transition-transform duration-700 group-hover:scale-110"
                    />
                    <Badge variant="dark" className="absolute left-4 top-4">{post.category}</Badge>
                  </div>
                  <div className="p-6">
                    <div className="flex items-center gap-3 text-xs text-ink-400">
                      <span>{post.date}</span>
                      <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
                    </div>
                    <h3 className="mt-3 font-display text-xl leading-snug transition-colors group-hover:text-gold-500">
                      {post.title}
                    </h3>
                    <p className="mt-2 text-sm text-ink-300">{post.excerpt}</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-sm text-gold-500">
                      Read <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </span>
                  </div>
                </Link>
              </motion.article>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
