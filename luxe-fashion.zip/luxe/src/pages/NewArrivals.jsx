import { getByTag } from "@/data/products";
import { PageHeader } from "@/components/common/PageHeader";
import { CollectionView } from "@/components/common/CollectionView";

export default function NewArrivals() {
  return (
    <>
      <PageHeader
        title="New Arrivals"
        subtitle="Fresh from the atelier — the latest additions to the LUXE wardrobe."
        crumbs={[{ label: "New Arrivals" }]}
      />
      <CollectionView products={getByTag("new")} />
    </>
  );
}
