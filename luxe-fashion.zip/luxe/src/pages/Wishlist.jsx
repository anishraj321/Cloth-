import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { getProductById } from "@/data/products";
import { useWishlist } from "@/context/WishlistContext";
import { PageHeader } from "@/components/common/PageHeader";
import { ProductGrid } from "@/components/common/ProductGrid";
import { Button } from "@/components/ui/button";

export default function Wishlist() {
  const { items, clear } = useWishlist();
  const products = items.map(getProductById).filter(Boolean);

  return (
    <>
      <PageHeader
        title="Wishlist"
        subtitle="The pieces you're dreaming about — saved for the perfect moment."
        crumbs={[{ label: "Wishlist" }]}
      />
      <section className="container pb-24">
        {products.length ? (
          <>
            <div className="mb-8 flex items-center justify-between">
              <p className="text-sm text-ink-400">
                <span className="text-gold-500">{products.length}</span> saved
              </p>
              <Button variant="ghost" size="sm" onClick={clear}>
                Clear all
              </Button>
            </div>
            <ProductGrid products={products} columns={4} />
          </>
        ) : (
          <div className="grid place-items-center rounded-3xl glass py-28 text-center">
            <div className="grid h-20 w-20 place-items-center rounded-full glass">
              <Heart className="text-gold-500" />
            </div>
            <p className="mt-6 font-display text-2xl">Your wishlist is empty</p>
            <p className="mt-2 text-ink-400">Tap the heart on any piece to save it here.</p>
            <Link to="/shop" className="mt-6">
              <Button>Discover pieces</Button>
            </Link>
          </div>
        )}
      </section>
    </>
  );
}
