import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { categories } from "@/data/collections";
import { PageHeader } from "@/components/common/PageHeader";
import { LazyImage } from "@/components/common/LazyImage";
import { Reveal } from "@/components/common/Reveal";

/** Grid of category tiles that deep-link into the filtered shop. */
export default function Categories() {
  return (
    <>
      <PageHeader
        title="Categories"
        subtitle="Explore the house by discipline — from outerwear to accessories."
        crumbs={[{ label: "Categories" }]}
      />
      <section className="container pb-24">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => (
            <Reveal key={c.id} index={i}>
              <Link
                to={c.to}
                className="group relative block overflow-hidden rounded-3xl"
              >
                <LazyImage
                  src={c.image}
                  alt={c.name}
                  className="aspect-[4/5]"
                  imgClassName="transition-transform duration-[1200ms] group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6">
                  <div>
                    <h3 className="font-display text-3xl">{c.name}</h3>
                    <p className="text-sm text-ink-400">{c.count} pieces</p>
                  </div>
                  <span className="grid h-11 w-11 place-items-center rounded-full glass-strong transition-all group-hover:bg-gold-gradient group-hover:text-ink-950">
                    <ArrowUpRight size={18} />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
