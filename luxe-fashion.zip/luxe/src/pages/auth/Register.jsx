import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { Mail, Lock, User } from "lucide-react";
import { AuthLayout } from "@/components/layout/AuthLayout";
import { AuthField } from "@/components/common/AuthField";
import { SocialAuth } from "@/components/common/SocialAuth";
import { SuccessTransition } from "@/components/common/SuccessTransition";
import { Button } from "@/components/ui/button";

// A tiny password strength meter.
function strengthOf(pw) {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return score;
}
const labels = ["Too weak", "Weak", "Fair", "Good", "Strong"];
const colors = ["#ef4444", "#f59e0b", "#eab308", "#84cc16", "#22c55e"];

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [agree, setAgree] = useState(false);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const strength = useMemo(() => strengthOf(form.password), [form.password]);

  const submit = (e) => {
    e.preventDefault();
    const errs = {};
    if (!form.name) errs.name = "Required";
    if (!form.email.includes("@")) errs.email = "Enter a valid email";
    if (strength < 3) errs.password = "Choose a stronger password";
    if (!agree) errs.agree = "Please accept the terms";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    // Route to OTP verification, then home.
    navigate("/otp-verification", { state: { email: form.email } });
  };

  return (
    <>
      <AnimatePresence>{success && <SuccessTransition />}</AnimatePresence>
      <AuthLayout
        title="Create your account"
        subtitle="Join the inner circle for early access and private sales."
        footer={
          <>
            Already have an account?{" "}
            <Link to="/login" className="text-gold-500 hover:underline">
              Sign in
            </Link>
          </>
        }
      >
        <form onSubmit={submit} className="space-y-5">
          <AuthField label="Full name" icon={User} value={form.name} onChange={set("name")} error={errors.name} autoComplete="name" />
          <AuthField label="Email" type="email" icon={Mail} value={form.email} onChange={set("email")} error={errors.email} autoComplete="email" />
          <div>
            <AuthField label="Password" type="password" icon={Lock} value={form.password} onChange={set("password")} error={errors.password} autoComplete="new-password" />
            {form.password && (
              <div className="mt-2">
                <div className="flex gap-1">
                  {[0, 1, 2, 3].map((i) => (
                    <span
                      key={i}
                      className="h-1 flex-1 rounded-full transition-colors"
                      style={{ background: i < strength ? colors[strength] : "rgba(255,255,255,0.1)" }}
                    />
                  ))}
                </div>
                <p className="mt-1 text-xs" style={{ color: colors[strength] }}>{labels[strength]}</p>
              </div>
            )}
          </div>

          <label className="flex cursor-pointer items-start gap-2 text-sm text-ink-300">
            <button
              type="button"
              onClick={() => setAgree((a) => !a)}
              className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded border transition-colors ${agree ? "border-gold-500 bg-gold-gradient text-ink-950" : "border-white/25"}`}
            >
              {agree && "✓"}
            </button>
            <span>
              I agree to the <a className="text-gold-500 hover:underline" href="#">Terms</a> and{" "}
              <a className="text-gold-500 hover:underline" href="#">Privacy Policy</a>.
            </span>
          </label>
          {errors.agree && <p className="-mt-3 text-xs text-red-400">{errors.agree}</p>}

          <Button type="submit" className="w-full" size="lg">Create account</Button>

          <div className="flex items-center gap-4">
            <span className="h-px flex-1 bg-white/10" />
            <span className="text-xs text-ink-400">or sign up with</span>
            <span className="h-px flex-1 bg-white/10" />
          </div>
          <SocialAuth onProvider={() => navigate("/otp-verification", { state: { email: form.email } })} />
        </form>
      </AuthLayout>
    </>
  );
}
