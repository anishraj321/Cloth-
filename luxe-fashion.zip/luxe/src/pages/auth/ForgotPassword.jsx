import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Mail, Check } from "lucide-react";
import { AuthLayout } from "@/components/layout/AuthLayout";
import { AuthField } from "@/components/common/AuthField";
import { Button } from "@/components/ui/button";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (!email.includes("@")) return setError("Enter a valid email");
    setError("");
    setSent(true);
  };

  return (
    <AuthLayout
      title="Reset password"
      subtitle={sent ? undefined : "Enter your email and we'll send a secure reset link."}
      footer={
        <>
          Remembered it?{" "}
          <Link to="/login" className="text-gold-500 hover:underline">
            Back to sign in
          </Link>
        </>
      }
    >
      <AnimatePresence mode="wait">
        {sent ? (
          <motion.div
            key="done"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-gold-gradient text-ink-950">
              <Check size={32} />
            </div>
            <p className="mt-6 font-display text-xl">Check your inbox</p>
            <p className="mt-2 text-sm text-ink-300">
              We've sent a reset link to <span className="text-gold-500">{email}</span>.
            </p>
            <Link to="/login" className="mt-6 inline-block">
              <Button variant="outline">Back to sign in</Button>
            </Link>
          </motion.div>
        ) : (
          <motion.form
            key="form"
            onSubmit={submit}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-5"
          >
            <AuthField label="Email" type="email" icon={Mail} value={email} onChange={(e) => setEmail(e.target.value)} error={error} autoComplete="email" />
            <Button type="submit" className="w-full" size="lg">Send reset link</Button>
          </motion.form>
        )}
      </AnimatePresence>
    </AuthLayout>
  );
}
