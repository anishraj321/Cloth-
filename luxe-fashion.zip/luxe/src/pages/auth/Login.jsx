import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { Mail, Lock } from "lucide-react";
import { AuthLayout } from "@/components/layout/AuthLayout";
import { AuthField } from "@/components/common/AuthField";
import { SocialAuth } from "@/components/common/SocialAuth";
import { SuccessTransition } from "@/components/common/SuccessTransition";
import { Button } from "@/components/ui/button";

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = (e) => {
    e.preventDefault();
    const errs = {};
    if (!form.email.includes("@")) errs.email = "Enter a valid email";
    if (form.password.length < 6) errs.password = "At least 6 characters";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setLoading(true);
    // Simulate an auth request, then play the premium transition.
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setTimeout(() => navigate("/"), 1500);
    }, 900);
  };

  return (
    <>
      <AnimatePresence>{success && <SuccessTransition label="Welcome back" />}</AnimatePresence>
      <AuthLayout
        title="Welcome back"
        subtitle="Sign in to continue your LUXE experience."
        footer={
          <>
            New to LUXE?{" "}
            <Link to="/register" className="text-gold-500 hover:underline">
              Create an account
            </Link>
          </>
        }
      >
        <form onSubmit={submit} className="space-y-5">
          <AuthField label="Email" type="email" icon={Mail} value={form.email} onChange={set("email")} error={errors.email} autoComplete="email" />
          <AuthField label="Password" type="password" icon={Lock} value={form.password} onChange={set("password")} error={errors.password} autoComplete="current-password" />

          <div className="flex items-center justify-between text-sm">
            <label className="flex cursor-pointer items-center gap-2 text-ink-300">
              <button
                type="button"
                onClick={() => setRemember((r) => !r)}
                className={`grid h-5 w-5 place-items-center rounded border transition-colors ${remember ? "border-gold-500 bg-gold-gradient text-ink-950" : "border-white/25"}`}
                aria-pressed={remember}
              >
                {remember && "✓"}
              </button>
              Remember me
            </label>
            <Link to="/forgot-password" className="text-gold-500 hover:underline">
              Forgot password?
            </Link>
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={loading}>
            {loading ? "Signing in…" : "Sign In"}
          </Button>

          <div className="flex items-center gap-4">
            <span className="h-px flex-1 bg-white/10" />
            <span className="text-xs text-ink-400">or continue with</span>
            <span className="h-px flex-1 bg-white/10" />
          </div>
          <SocialAuth onProvider={submit} />
        </form>
      </AuthLayout>
    </>
  );
}
