import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { AuthLayout } from "@/components/layout/AuthLayout";
import { SuccessTransition } from "@/components/common/SuccessTransition";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/** Six-box OTP entry with auto-advance, paste support, and a resend timer. */
export default function OTPVerification() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const email = state?.email || "your email";
  const [digits, setDigits] = useState(Array(6).fill(""));
  const [error, setError] = useState("");
  const [seconds, setSeconds] = useState(30);
  const [success, setSuccess] = useState(false);
  const refs = useRef([]);

  useEffect(() => {
    refs.current[0]?.focus();
  }, []);

  useEffect(() => {
    if (seconds <= 0) return;
    const id = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(id);
  }, [seconds]);

  const setAt = (i, val) => {
    setDigits((d) => {
      const next = [...d];
      next[i] = val;
      return next;
    });
  };

  const handleChange = (i, e) => {
    const val = e.target.value.replace(/\D/g, "").slice(-1);
    setAt(i, val);
    setError("");
    if (val && i < 5) refs.current[i + 1]?.focus();
  };

  const handleKey = (i, e) => {
    if (e.key === "Backspace" && !digits[i] && i > 0) refs.current[i - 1]?.focus();
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6).split("");
    if (pasted.length) {
      setDigits((d) => d.map((_, i) => pasted[i] || ""));
      refs.current[Math.min(pasted.length, 5)]?.focus();
    }
  };

  const verify = (e) => {
    e.preventDefault();
    if (digits.some((d) => !d)) return setError("Enter all six digits");
    setSuccess(true);
    setTimeout(() => navigate("/"), 1500);
  };

  return (
    <>
      <AnimatePresence>{success && <SuccessTransition label="Verified" />}</AnimatePresence>
      <AuthLayout
        title="Verify it's you"
        subtitle={`We sent a 6-digit code to ${email}.`}
        footer={
          <Link to="/login" className="text-gold-500 hover:underline">
            Back to sign in
          </Link>
        }
      >
        <form onSubmit={verify} className="space-y-6">
          <div className="flex justify-between gap-2" onPaste={handlePaste}>
            {digits.map((d, i) => (
              <input
                key={i}
                ref={(el) => (refs.current[i] = el)}
                value={d}
                onChange={(e) => handleChange(i, e)}
                onKeyDown={(e) => handleKey(i, e)}
                inputMode="numeric"
                maxLength={1}
                className={cn(
                  "h-14 w-full rounded-xl border bg-white/5 text-center font-display text-2xl outline-none transition-colors focus:border-gold-500/70",
                  d ? "border-gold-500/50 text-gold-500" : "border-white/10",
                  error && "border-red-400/70"
                )}
              />
            ))}
          </div>
          {error && <p className="text-center text-xs text-red-400">{error}</p>}

          <Button type="submit" className="w-full" size="lg">Verify</Button>

          <p className="text-center text-sm text-ink-400">
            {seconds > 0 ? (
              <>Resend code in <span className="text-gold-500">{seconds}s</span></>
            ) : (
              <button type="button" onClick={() => setSeconds(30)} className="text-gold-500 hover:underline">
                Resend code
              </button>
            )}
          </p>
        </form>
      </AuthLayout>
    </>
  );
}
