import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Send, Check } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/common/Reveal";

const channels = [
  { icon: Mail, label: "Email", value: "concierge@luxe.house" },
  { icon: Phone, label: "Phone", value: "+1 (800) 555-LUXE" },
  { icon: MapPin, label: "Flagship", value: "Via Montenapoleone, Milan" },
];

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState({});

  const submit = (e) => {
    e.preventDefault();
    const errs = {};
    if (!form.name) errs.name = "Required";
    if (!form.email.includes("@")) errs.email = "Enter a valid email";
    if (form.message.length < 10) errs.message = "Tell us a little more";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setSent(true);
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <>
      <PageHeader
        title="Let's Talk"
        subtitle="Our concierge team responds within one business day. We'd love to hear from you."
        crumbs={[{ label: "Contact" }]}
      />

      <section className="container pb-24">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
          {/* Channels */}
          <div className="space-y-6">
            {channels.map((c, i) => (
              <Reveal key={c.label} index={i}>
                <div className="flex items-center gap-4 rounded-2xl glass p-6">
                  <div className="grid h-12 w-12 place-items-center rounded-xl bg-gold-500/10 text-gold-500">
                    <c.icon size={20} />
                  </div>
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-ink-400">{c.label}</p>
                    <p className="font-display text-lg">{c.value}</p>
                  </div>
                </div>
              </Reveal>
            ))}
            <Reveal>
              <div className="overflow-hidden rounded-2xl glass">
                <iframe
                  title="LUXE flagship"
                  src="https://www.openstreetmap.org/export/embed.html?bbox=9.19%2C45.46%2C9.21%2C45.48&layer=mapnik"
                  className="h-56 w-full grayscale"
                  loading="lazy"
                />
              </div>
            </Reveal>
          </div>

          {/* Form */}
          <Reveal direction="left">
            <form onSubmit={submit} className="rounded-3xl glass-strong p-8">
              {sent ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="grid place-items-center py-20 text-center"
                >
                  <div className="grid h-16 w-16 place-items-center rounded-full bg-gold-gradient text-ink-950">
                    <Check size={32} />
                  </div>
                  <p className="mt-6 font-display text-2xl">Message received</p>
                  <p className="mt-2 text-ink-400">We'll be in touch shortly.</p>
                  <Button type="button" variant="outline" className="mt-6" onClick={() => setSent(false)}>
                    Send another
                  </Button>
                </motion.div>
              ) : (
                <div className="space-y-5">
                  <h3 className="font-display text-2xl">Send a message</h3>
                  <div>
                    <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-ink-400">Name</label>
                    <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className={errors.name ? "border-red-400/70" : ""} />
                    {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
                  </div>
                  <div>
                    <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-ink-400">Email</label>
                    <Input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} className={errors.email ? "border-red-400/70" : ""} />
                    {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
                  </div>
                  <div>
                    <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-widest text-ink-400">Message</label>
                    <textarea
                      rows={5}
                      value={form.message}
                      onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                      className={`w-full rounded-xl border bg-white/5 p-4 text-sm outline-none transition-colors focus:border-gold-500/60 ${errors.message ? "border-red-400/70" : "border-white/10"}`}
                    />
                    {errors.message && <p className="mt-1 text-xs text-red-400">{errors.message}</p>}
                  </div>
                  <Button type="submit" className="w-full" size="lg">
                    <Send size={16} /> Send message
                  </Button>
                </div>
              )}
            </form>
          </Reveal>
        </div>
      </section>
    </>
  );
}
