import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Zap, ArrowRight } from "lucide-react";
import { getByTag } from "@/data/products";
import { ProductGrid } from "@/components/common/ProductGrid";
import { Button } from "@/components/ui/button";
import { MagneticButton } from "@/components/common/MagneticButton";
import { ParticleBackground } from "@/components/common/ParticleBackground";

function useCountdown(target) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = Math.max(0, target - now);
  return {
    hours: Math.floor(diff / 3.6e6),
    minutes: Math.floor((diff % 3.6e6) / 6e4),
    seconds: Math.floor((diff % 6e4) / 1000),
  };
}

/** Flash-sale band with a live countdown and the discounted products. */
export function FlashSale() {
  // Target = 1 day, 8 hours from first render (stable across ticks).
  const target = useMemo(() => Date.now() + (32 * 60 + 15) * 60 * 1000, []);
  const { hours, minutes, seconds } = useCountdown(target);
  const items = getByTag("sale").slice(0, 4);
  const units = [
    ["Hrs", hours],
    ["Min", minutes],
    ["Sec", seconds],
  ];

  return (
    <section className="relative my-24 overflow-hidden border-y border-gold-500/20 py-24">
      <ParticleBackground density={40} />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-gold-500/5 via-transparent to-gold-500/5" />
      <div className="container relative">
        <div className="flex flex-col items-center gap-6 text-center">
          <motion.span
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 rounded-full border border-gold-500/40 px-4 py-1.5 font-mono text-[11px] uppercase tracking-widest text-gold-500"
          >
            <Zap size={13} className="fill-gold-500" /> Flash Sale · Up to 40% off
          </motion.span>
          <h2 className="font-display text-5xl md:text-6xl">
            The <span className="text-gold-gradient italic">Gilded</span> Sale
          </h2>

          {/* Countdown */}
          <div className="flex items-center gap-3">
            {units.map(([label, value], i) => (
              <div key={label} className="flex items-center gap-3">
                <div className="flex flex-col items-center rounded-2xl glass-strong px-5 py-3">
                  <motion.span
                    key={value}
                    initial={{ y: -12, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="font-display text-3xl tabular-nums md:text-4xl"
                  >
                    {String(value).padStart(2, "0")}
                  </motion.span>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-ink-400">
                    {label}
                  </span>
                </div>
                {i < units.length - 1 && (
                  <span className="font-display text-3xl text-gold-500">:</span>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14">
          <ProductGrid products={items} />
        </div>

        <div className="mt-12 flex justify-center">
          <MagneticButton>
            <Link to="/sale">
              <Button size="lg">
                Shop the Sale <ArrowRight size={18} />
              </Button>
            </Link>
          </MagneticButton>
        </div>
      </div>
    </section>
  );
}
