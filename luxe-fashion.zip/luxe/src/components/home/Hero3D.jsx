import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Float, Environment, Lightformer, MeshDistortMaterial, Sphere, Torus } from "@react-three/drei";
import { usePrefersReducedMotion } from "@/hooks/useMediaQuery";

/**
 * A trio of floating, gold, distorting shapes rendered with React Three Fiber.
 * `Float` gives each object gentle, independent drift; `MeshDistortMaterial`
 * makes the sphere breathe. Kept low-poly and DPR-clamped for performance.
 */
function Shapes() {
  return (
    <>
      <Float speed={1.5} rotationIntensity={1.2} floatIntensity={2}>
        <Sphere args={[1, 64, 64]} position={[0, 0, 0]} scale={1.35}>
          <MeshDistortMaterial
            color="#d4af37"
            roughness={0.15}
            metalness={0.95}
            distort={0.35}
            speed={1.6}
          />
        </Sphere>
      </Float>

      <Float speed={2} rotationIntensity={2} floatIntensity={1.5}>
        <Torus args={[0.5, 0.18, 32, 100]} position={[2.4, 1.1, -1]}>
          <meshStandardMaterial color="#f4df94" roughness={0.2} metalness={1} />
        </Torus>
      </Float>

      <Float speed={1.8} rotationIntensity={1.5} floatIntensity={2.2}>
        <mesh position={[-2.5, -1, -1]}>
          <icosahedronGeometry args={[0.6, 0]} />
          <meshStandardMaterial color="#946c1b" roughness={0.25} metalness={0.9} flatShading />
        </mesh>
      </Float>
    </>
  );
}

export function Hero3D() {
  const reduced = usePrefersReducedMotion();
  if (reduced) return null;

  return (
    <Canvas
      dpr={[1, 1.8]}
      camera={{ position: [0, 0, 6], fov: 42 }}
      gl={{ antialias: true, alpha: true }}
      className="!absolute inset-0"
    >
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={1.2} color="#fff6d8" />
      <pointLight position={[-5, -3, 2]} intensity={1.5} color="#d4af37" />
      <Suspense fallback={null}>
        <Shapes />
        {/*
          A self-contained studio environment built from Lightformers — this
          gives the metallic materials rich reflections WITHOUT fetching any
          HDR file from the network (keeping the site fast and offline-safe).
        */}
        <Environment resolution={256}>
          <Lightformer intensity={2} color="#fff6d8" position={[0, 3, 2]} scale={[6, 3, 1]} />
          <Lightformer intensity={1.5} color="#d4af37" position={[-3, -1, 1]} scale={[3, 3, 1]} />
          <Lightformer intensity={1} color="#ffffff" position={[3, 1, -1]} scale={[3, 3, 1]} />
        </Environment>
      </Suspense>
    </Canvas>
  );
}
