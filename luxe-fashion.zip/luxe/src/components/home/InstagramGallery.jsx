import { motion } from "framer-motion";
import { Instagram } from "lucide-react";
import { instagram } from "@/data/content";
import { SectionHeading } from "@/components/common/SectionHeading";
import { LazyImage } from "@/components/common/LazyImage";

/** Instagram-style grid with a hover overlay revealing the IG glyph. */
export function InstagramGallery() {
  return (
    <section className="container py-24">
      <SectionHeading
        eyebrow="@luxe"
        title="Follow the Movement"
        subtitle="Tag #LUXEmuse to be featured across our channels."
      />
      <div className="mt-14 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {instagram.map((src, i) => (
          <motion.a
            key={i}
            href="#"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.06 }}
            className="group relative aspect-square overflow-hidden rounded-2xl"
          >
            <LazyImage
              src={src}
              alt="LUXE on Instagram"
              className="h-full w-full"
              imgClassName="transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 grid place-items-center bg-ink-950/60 opacity-0 backdrop-blur-sm transition-opacity group-hover:opacity-100">
              <Instagram className="text-gold-500" />
            </div>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
