import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { getByTag } from "@/data/products";
import { SectionHeading } from "@/components/common/SectionHeading";
import { ProductGrid } from "@/components/common/ProductGrid";
import { Button } from "@/components/ui/button";
import { MagneticButton } from "@/components/common/MagneticButton";

/** Home strip of the latest arrivals. */
export function NewArrivalsStrip() {
  const items = getByTag("new").slice(0, 4);
  return (
    <section className="container py-24">
      <SectionHeading eyebrow="Fresh In" title="New Arrivals" />
      <div className="mt-14">
        <ProductGrid products={items} />
      </div>
      <div className="mt-12 flex justify-center">
        <MagneticButton>
          <Link to="/new-arrivals">
            <Button variant="outline" size="lg">
              See everything new <ArrowRight size={18} />
            </Button>
          </Link>
        </MagneticButton>
      </div>
    </section>
  );
}
