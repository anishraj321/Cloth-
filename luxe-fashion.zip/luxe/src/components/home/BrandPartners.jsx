import { partners } from "@/data/collections";

/** An infinite, CSS-driven marquee of press / partner wordmarks. */
export function BrandPartners() {
  const row = [...partners, ...partners];
  return (
    <section className="border-y border-white/10 py-10">
      <div className="mask-fade-x relative flex overflow-hidden [--gap:5rem]">
        <div className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-[--gap] pr-[--gap]">
          {row.map((p, i) => (
            <span
              key={i}
              className="font-display text-3xl font-semibold text-ink-400 transition-colors hover:text-gold-500 md:text-4xl"
            >
              {p}
            </span>
          ))}
        </div>
        <div
          aria-hidden
          className="flex shrink-0 animate-[marquee_28s_linear_infinite] items-center gap-[--gap] pr-[--gap]"
        >
          {row.map((p, i) => (
            <span
              key={i}
              className="font-display text-3xl font-semibold text-ink-400 md:text-4xl"
            >
              {p}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
