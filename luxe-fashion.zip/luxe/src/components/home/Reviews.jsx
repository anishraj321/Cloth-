import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { reviews } from "@/data/content";
import { SectionHeading } from "@/components/common/SectionHeading";
import { Rating } from "@/components/common/Rating";
import { LazyImage } from "@/components/common/LazyImage";

/** A one-at-a-time testimonial carousel with directional slide animation. */
export function Reviews() {
  const [[index, dir], setState] = useState([0, 0]);
  const review = reviews[index];

  const paginate = (d) =>
    setState(([i]) => [(i + d + reviews.length) % reviews.length, d]);

  return (
    <section className="container py-24">
      <SectionHeading eyebrow="In Their Words" title="Loved by Tastemakers" />

      <div className="relative mx-auto mt-14 max-w-3xl">
        <Quote className="mx-auto mb-6 h-10 w-10 text-gold-500/40" />
        <div className="relative h-56 md:h-44">
          <AnimatePresence mode="wait" custom={dir}>
            <motion.div
              key={index}
              custom={dir}
              initial={{ opacity: 0, x: dir > 0 ? 60 : -60 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: dir > 0 ? -60 : 60 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="absolute inset-0 flex flex-col items-center text-center"
            >
              <p className="font-display text-2xl leading-relaxed md:text-3xl">
                “{review.text}”
              </p>
              <div className="mt-8 flex items-center gap-4">
                <LazyImage
                  src={review.avatar}
                  alt={review.name}
                  className="h-14 w-14 rounded-full"
                />
                <div className="text-left">
                  <p className="font-medium">{review.name}</p>
                  <p className="text-xs text-ink-400">{review.role}</p>
                  <Rating value={review.rating} className="mt-1" size={12} />
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-8 flex items-center justify-center gap-4">
          <button
            onClick={() => paginate(-1)}
            className="grid h-11 w-11 place-items-center rounded-full glass transition-colors hover:text-gold-500"
            aria-label="Previous review"
          >
            <ChevronLeft size={18} />
          </button>
          <div className="flex gap-2">
            {reviews.map((_, i) => (
              <button
                key={i}
                onClick={() => setState([i, i > index ? 1 : -1])}
                className={`h-1.5 rounded-full transition-all ${
                  i === index ? "w-8 bg-gold-gradient" : "w-1.5 bg-white/20"
                }`}
                aria-label={`Go to review ${i + 1}`}
              />
            ))}
          </div>
          <button
            onClick={() => paginate(1)}
            className="grid h-11 w-11 place-items-center rounded-full glass transition-colors hover:text-gold-500"
            aria-label="Next review"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
