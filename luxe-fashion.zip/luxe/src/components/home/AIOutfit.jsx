import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, RefreshCw } from "lucide-react";
import { products } from "@/data/products";
import { SectionHeading } from "@/components/common/SectionHeading";
import { LazyImage } from "@/components/common/LazyImage";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/utils";

const moods = ["Black Tie", "Off Duty", "Power Meeting", "Golden Hour", "Weekend"];

/**
 * A playful "AI stylist" that assembles a three-piece outfit for a chosen mood.
 * The selection is simulated client-side — swap `curate()` for a real endpoint.
 */
export function AIOutfit() {
  const [mood, setMood] = useState(moods[0]);
  const [seed, setSeed] = useState(0);
  const [loading, setLoading] = useState(false);

  const curate = () => {
    // Deterministic-ish rotation so re-styling feels responsive.
    const start = (seed * 3) % products.length;
    return [0, 1, 2].map((i) => products[(start + i * 2) % products.length]);
  };
  const outfit = curate();

  const restyle = () => {
    setLoading(true);
    setTimeout(() => {
      setSeed((s) => s + 1);
      setLoading(false);
    }, 700);
  };

  return (
    <section className="container py-24">
      <div className="overflow-hidden rounded-[2rem] glass-strong p-8 md:p-14">
        <div className="flex flex-col items-start gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            align="left"
            eyebrow="AI Stylist"
            title="Your Outfit, Curated"
            subtitle="Tell us the occasion — our stylist assembles a look in a heartbeat."
          />
          <Button variant="glass" onClick={restyle} className="shrink-0">
            <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
            Re-style
          </Button>
        </div>

        {/* Mood chips */}
        <div className="mt-8 flex flex-wrap gap-2">
          {moods.map((m) => (
            <button
              key={m}
              onClick={() => {
                setMood(m);
                restyle();
              }}
              className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm transition-all ${
                mood === m
                  ? "border-gold-500 bg-gold-500/10 text-gold-500"
                  : "border-white/10 text-ink-300 hover:border-white/30"
              }`}
            >
              {mood === m && <Sparkles size={13} />}
              {m}
            </button>
          ))}
        </div>

        {/* Curated trio */}
        <div className="mt-10 grid gap-6 sm:grid-cols-3">
          <AnimatePresence mode="wait">
            {outfit.map((p, i) => (
              <motion.div
                key={`${p.id}-${seed}`}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: i * 0.1 }}
                className="group overflow-hidden rounded-2xl glass"
              >
                <LazyImage src={p.images[0]} alt={p.name} className="aspect-[3/4]" />
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-display">{p.name}</p>
                    <p className="text-xs text-ink-400">{p.subcategory}</p>
                  </div>
                  <span className="text-gold-500">{formatPrice(p.salePrice || p.price)}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
