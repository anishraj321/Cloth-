import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { getByTag } from "@/data/products";
import { SectionHeading } from "@/components/common/SectionHeading";
import { ProductGrid } from "@/components/common/ProductGrid";
import { Button } from "@/components/ui/button";
import { MagneticButton } from "@/components/common/MagneticButton";
import { Reveal } from "@/components/common/Reveal";

/** "Trending now" grid, pulled from products tagged `trending`. */
export function TrendingProducts() {
  const items = getByTag("trending").slice(0, 4);
  return (
    <section className="container py-24">
      <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
        <SectionHeading
          align="left"
          eyebrow="Most Wanted"
          title="Trending Now"
          subtitle="The pieces everyone is reaching for this week."
        />
        <Reveal>
          <MagneticButton>
            <Link to="/best-sellers">
              <Button variant="outline">
                View all <ArrowRight size={16} />
              </Button>
            </Link>
          </MagneticButton>
        </Reveal>
      </div>
      <div className="mt-14">
        <ProductGrid products={items} />
      </div>
    </section>
  );
}
