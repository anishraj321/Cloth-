import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { collections } from "@/data/collections";
import { SectionHeading } from "@/components/common/SectionHeading";
import { LazyImage } from "@/components/common/LazyImage";
import { Reveal } from "@/components/common/Reveal";

/** Editorial collection tiles with a large hero tile and image zoom on hover. */
export function FeaturedCollections() {
  return (
    <section className="container py-24">
      <SectionHeading
        eyebrow="Curated"
        title="Featured Collections"
        subtitle="Three worlds, one obsession with detail. Step inside the season's defining edits."
      />

      <div className="mt-14 grid gap-6 lg:grid-cols-3">
        {collections.map((c, i) => (
          <Reveal key={c.id} index={i} className={i === 0 ? "lg:row-span-2 lg:col-span-1" : ""}>
            <Link
              to={c.to}
              className="group relative block h-full overflow-hidden rounded-3xl"
            >
              <LazyImage
                src={c.image}
                alt={c.title}
                className={i === 0 ? "aspect-[3/4] lg:h-full" : "aspect-[16/10]"}
                imgClassName="transition-transform duration-[1200ms] group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/20 to-transparent" />
              <div className="absolute inset-0 flex flex-col justify-end p-7">
                <p className="font-mono text-[10px] uppercase tracking-luxe text-gold-500">
                  {c.subtitle}
                </p>
                <h3 className="mt-2 font-display text-3xl">{c.title}</h3>
                <p className="mt-1 max-w-xs text-sm text-ink-300">{c.description}</p>
                <motion.span className="mt-4 inline-flex items-center gap-1 text-sm text-gold-500">
                  Discover
                  <ArrowUpRight
                    size={16}
                    className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1"
                  />
                </motion.span>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
