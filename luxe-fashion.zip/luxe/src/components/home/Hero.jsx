import { Suspense, lazy } from "react";
import { Link } from "react-router-dom";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, ArrowDown } from "lucide-react";
import { MagneticButton } from "@/components/common/MagneticButton";
import { ParticleBackground } from "@/components/common/ParticleBackground";
import { Button } from "@/components/ui/button";
import { LazyImage } from "@/components/common/LazyImage";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";

// The 3D canvas is heavy — load it lazily so first paint stays instant.
const Hero3D = lazy(() =>
  import("./Hero3D").then((m) => ({ default: m.Hero3D }))
);

const HERO_IMG =
  "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1400&q=80";

export function Hero() {
  const { scrollYProgress } = useScroll();
  // Parallax layers move at different speeds as you scroll out of the hero.
  const yImg = useTransform(scrollYProgress, [0, 0.4], [0, 140]);
  const yText = useTransform(scrollYProgress, [0, 0.4], [0, -80]);
  const opacity = useTransform(scrollYProgress, [0, 0.35], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.4], [1, 1.1]);

  return (
    <section className="relative flex min-h-screen items-center overflow-hidden pt-24">
      {/* Ambient gradients + particles */}
      <div className="absolute inset-0 bg-radial-fade" />
      <ParticleBackground density={70} />

      {/* 3D floating accessories — isolated so a WebGL failure never blanks the page */}
      <div className="absolute inset-0 opacity-80">
        <ErrorBoundary fallback={null}>
          <Suspense fallback={null}>
            <Hero3D />
          </Suspense>
        </ErrorBoundary>
      </div>

      <div className="container relative z-10 grid items-center gap-10 lg:grid-cols-2">
        {/* Copy */}
        <motion.div style={{ y: yText, opacity }} className="order-2 lg:order-1">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="eyebrow flex items-center gap-3"
          >
            <span className="h-px w-10 bg-gold-500/60" />
            Autumn / Winter 2026
          </motion.span>

          <h1 className="mt-6 font-display text-6xl font-bold leading-[0.95] md:text-7xl xl:text-8xl">
            {["Redefine", "Your", "Elegance"].map((word, i) => (
              <span key={word} className="block overflow-hidden">
                <motion.span
                  className="inline-block"
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ delay: 0.35 + i * 0.12, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                >
                  {i === 2 ? (
                    <span className="text-gold-gradient italic">{word}</span>
                  ) : (
                    word
                  )}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="mt-6 max-w-md text-lg text-ink-300"
          >
            A cinematic collection of sculptural silhouettes, rare fabrics, and
            gold-thread craftsmanship. Dress like the moment belongs to you.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.05 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <MagneticButton strength={0.5}>
              <Link to="/shop">
                <Button size="lg" className="group animate-pulse-glow">
                  Explore Collection
                  <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </MagneticButton>
            <MagneticButton strength={0.4}>
              <Link to="/new-arrivals">
                <Button size="lg" variant="outline">
                  New Arrivals
                </Button>
              </Link>
            </MagneticButton>
          </motion.div>

          {/* Stat strip */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
            className="mt-12 flex gap-10"
          >
            {[
              ["12k+", "Members"],
              ["4.9★", "Rated"],
              ["120+", "Countries"],
            ].map(([n, l]) => (
              <div key={l}>
                <p className="font-display text-2xl text-gold-gradient">{n}</p>
                <p className="text-xs uppercase tracking-widest text-ink-400">{l}</p>
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Model image with parallax + float */}
        <motion.div
          style={{ y: yImg, scale }}
          className="order-1 lg:order-2"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="relative mx-auto max-w-md">
            <div className="absolute -inset-4 rounded-[2rem] bg-gold-gradient opacity-20 blur-3xl" />
            <div className="relative overflow-hidden rounded-[2rem] border border-gold-500/20">
              <LazyImage
                src={HERO_IMG}
                alt="LUXE fashion model in the Autumn/Winter collection"
                className="aspect-[3/4] animate-float"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent" />
              {/* Floating price tag */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.4 }}
                className="absolute bottom-6 left-6 rounded-2xl glass-strong p-4"
              >
                <p className="font-mono text-[10px] uppercase tracking-widest text-gold-500">
                  Featured
                </p>
                <p className="font-display text-lg">The Noir Trench</p>
                <p className="text-sm text-ink-300">$890</p>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <motion.div
        style={{ opacity }}
        className="absolute inset-x-0 bottom-8 flex flex-col items-center gap-2 text-ink-400"
      >
        <span className="font-mono text-[10px] uppercase tracking-luxe">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.8 }}
        >
          <ArrowDown size={16} className="text-gold-500" />
        </motion.div>
      </motion.div>
    </section>
  );
}
