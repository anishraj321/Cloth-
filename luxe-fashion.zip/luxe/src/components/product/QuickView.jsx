import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X, ShoppingBag, Heart, ArrowRight } from "lucide-react";
import { LazyImage } from "@/components/common/LazyImage";
import { Rating } from "@/components/common/Rating";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useLockBodyScroll } from "@/hooks/useLockBodyScroll";
import { cn, formatPrice } from "@/lib/utils";

/** A glassy modal for previewing a product without leaving the grid. */
export function QuickView({ product, onClose }) {
  const open = Boolean(product);
  useLockBodyScroll(open);
  const { addItem } = useCart();
  const { has, toggle } = useWishlist();
  const [size, setSize] = useState(null);
  const [color, setColor] = useState(null);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[95] grid place-items-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-ink-950/70 backdrop-blur-md"
            onClick={onClose}
          />
          <motion.div
            className="relative z-10 grid w-full max-w-4xl grid-cols-1 overflow-hidden rounded-3xl glass-strong md:grid-cols-2"
            initial={{ scale: 0.92, y: 30, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.92, y: 30, opacity: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 26 }}
          >
            <button
              onClick={onClose}
              aria-label="Close"
              className="absolute right-4 top-4 z-20 grid h-10 w-10 place-items-center rounded-full glass-strong transition-transform hover:rotate-90"
            >
              <X size={18} />
            </button>

            <LazyImage
              src={product.images[0]}
              alt={product.name}
              className="aspect-[4/5] md:aspect-auto md:h-full"
            />

            <div className="flex flex-col gap-5 p-8">
              <div>
                <p className="eyebrow">{product.subcategory}</p>
                <h3 className="mt-2 font-display text-3xl">{product.name}</h3>
                <Rating value={product.rating} count={product.reviewsCount} className="mt-2" />
              </div>

              <div className="flex items-baseline gap-3">
                <span className="font-display text-2xl text-gold-gradient">
                  {formatPrice(product.salePrice || product.price)}
                </span>
                {product.salePrice && (
                  <span className="text-ink-400 line-through">
                    {formatPrice(product.price)}
                  </span>
                )}
              </div>

              <p className="text-sm leading-relaxed text-ink-300">
                {product.description}
              </p>

              {/* Colors */}
              <div>
                <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-ink-400">
                  Colour
                </p>
                <div className="flex gap-2">
                  {product.colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setColor(c.name)}
                      title={c.name}
                      style={{ background: c.hex }}
                      className={cn(
                        "h-8 w-8 rounded-full border-2 transition-transform hover:scale-110",
                        color === c.name ? "border-gold-500" : "border-white/20"
                      )}
                    />
                  ))}
                </div>
              </div>

              {/* Sizes */}
              <div>
                <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-ink-400">
                  Size
                </p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={cn(
                        "h-10 min-w-[2.75rem] rounded-lg border px-3 text-sm transition-all",
                        size === s
                          ? "border-gold-500 bg-gold-500/10 text-gold-500"
                          : "border-white/15 hover:border-white/40"
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-auto flex items-center gap-3 pt-2">
                <Button
                  className="flex-1"
                  onClick={() => {
                    addItem(product, { size: size || product.sizes[0], color: color || product.colors[0]?.name });
                    onClose();
                  }}
                >
                  <ShoppingBag size={16} /> Add to Bag
                </Button>
                <Button
                  variant="glass"
                  size="icon"
                  onClick={() => toggle(product.id)}
                  aria-label="Wishlist"
                >
                  <Heart
                    size={18}
                    className={has(product.id) ? "fill-gold-500 text-gold-500" : ""}
                  />
                </Button>
              </div>

              <Link
                to={`/product/${product.id}`}
                onClick={onClose}
                className="group inline-flex items-center gap-1 text-sm text-gold-500"
              >
                View full details
                <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
