import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SlidersHorizontal, X, Check, Search } from "lucide-react";
import { priceRange } from "@/data/products";
import { ProductGrid } from "./ProductGrid";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn, formatPrice } from "@/lib/utils";

const SORTS = [
  { id: "featured", label: "Featured" },
  { id: "price-asc", label: "Price: Low to High" },
  { id: "price-desc", label: "Price: High to Low" },
  { id: "rating", label: "Top Rated" },
];

/**
 * CollectionView — the reusable listing experience powering Shop, Men, Women,
 * New Arrivals, Best Sellers and Sale. Provides search, category chips, a price
 * ceiling slider and sort, all applied client-side with graceful empty states.
 */
export function CollectionView({ products, loading = false }) {
  const { max } = priceRange();
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("featured");
  const [maxPrice, setMaxPrice] = useState(max);
  const [activeCats, setActiveCats] = useState([]);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const categories = useMemo(
    () => [...new Set(products.map((p) => p.subcategory))],
    [products]
  );

  const filtered = useMemo(() => {
    let list = products.filter((p) => {
      const price = p.salePrice || p.price;
      const matchesQuery =
        !query ||
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.subcategory.toLowerCase().includes(query.toLowerCase());
      const matchesCat =
        activeCats.length === 0 || activeCats.includes(p.subcategory);
      return price <= maxPrice && matchesQuery && matchesCat;
    });

    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => (a.salePrice || a.price) - (b.salePrice || b.price));
        break;
      case "price-desc":
        list = [...list].sort((a, b) => (b.salePrice || b.price) - (a.salePrice || a.price));
        break;
      case "rating":
        list = [...list].sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }
    return list;
  }, [products, query, sort, maxPrice, activeCats]);

  const toggleCat = (c) =>
    setActiveCats((prev) =>
      prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]
    );

  const Filters = (
    <div className="space-y-8">
      {/* Search */}
      <div>
        <label className="mb-3 block font-mono text-[10px] uppercase tracking-widest text-ink-400">
          Search
        </label>
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find a piece…"
            className="h-11 w-full rounded-xl border border-white/10 bg-white/5 pl-9 pr-3 text-sm outline-none focus:border-gold-500/60"
          />
        </div>
      </div>

      {/* Categories */}
      {categories.length > 1 && (
        <div>
          <p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-ink-400">
            Category
          </p>
          <div className="flex flex-col gap-1">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => toggleCat(c)}
                className="flex items-center gap-3 rounded-lg px-2 py-2 text-left text-sm transition-colors hover:bg-white/5"
              >
                <span
                  className={cn(
                    "grid h-4 w-4 place-items-center rounded border transition-colors",
                    activeCats.includes(c)
                      ? "border-gold-500 bg-gold-500 text-ink-950"
                      : "border-white/25"
                  )}
                >
                  {activeCats.includes(c) && <Check size={11} />}
                </span>
                {c}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Price slider */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <p className="font-mono text-[10px] uppercase tracking-widest text-ink-400">
            Max price
          </p>
          <span className="text-sm text-gold-500">{formatPrice(maxPrice)}</span>
        </div>
        <input
          type="range"
          min={100}
          max={max}
          step={10}
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="w-full accent-gold-500"
        />
      </div>
    </div>
  );

  return (
    <section className="container pb-24">
      <div className="grid gap-10 lg:grid-cols-[260px_1fr]">
        {/* Desktop sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-28 rounded-2xl glass p-6">{Filters}</div>
        </aside>

        <div>
          {/* Toolbar */}
          <div className="mb-8 flex items-center justify-between gap-4">
            <p className="text-sm text-ink-400">
              <span className="text-gold-500">{filtered.length}</span> pieces
            </p>
            <div className="flex items-center gap-3">
              <Button
                variant="glass"
                size="sm"
                className="lg:hidden"
                onClick={() => setFiltersOpen(true)}
              >
                <SlidersHorizontal size={14} /> Filters
              </Button>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="h-9 rounded-full border border-white/10 bg-white/5 px-4 text-sm outline-none focus:border-gold-500/60"
              >
                {SORTS.map((s) => (
                  <option key={s.id} value={s.id} className="bg-ink-900">
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Grid / skeletons / empty */}
          {loading ? (
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 xl:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="aspect-[3/4] w-full rounded-2xl" />
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-4 w-1/3" />
                </div>
              ))}
            </div>
          ) : filtered.length ? (
            <ProductGrid products={filtered} columns={3} />
          ) : (
            <div className="grid place-items-center rounded-2xl glass py-24 text-center">
              <p className="font-display text-2xl">Nothing matches — yet.</p>
              <p className="mt-2 text-ink-400">Try widening your filters.</p>
              <Button
                variant="outline"
                className="mt-6"
                onClick={() => {
                  setQuery("");
                  setActiveCats([]);
                  setMaxPrice(max);
                }}
              >
                Reset filters
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile filter sheet */}
      <AnimatePresence>
        {filtersOpen && (
          <motion.div
            className="fixed inset-0 z-[85] lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 bg-ink-950/70 backdrop-blur-sm" onClick={() => setFiltersOpen(false)} />
            <motion.div
              className="absolute bottom-0 left-0 right-0 max-h-[80vh] overflow-y-auto rounded-t-3xl glass-strong p-6"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 32 }}
            >
              <div className="mb-6 flex items-center justify-between">
                <h3 className="font-display text-2xl">Filters</h3>
                <button onClick={() => setFiltersOpen(false)} aria-label="Close filters">
                  <X />
                </button>
              </div>
              {Filters}
              <Button className="mt-8 w-full" onClick={() => setFiltersOpen(false)}>
                Show {filtered.length} results
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
