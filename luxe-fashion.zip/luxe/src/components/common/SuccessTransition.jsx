import { motion } from "framer-motion";
import { Check } from "lucide-react";

/**
 * A premium full-screen gold sweep played after a successful login/action
 * before navigating on. Render conditionally when `show` is true.
 */
export function SuccessTransition({ label = "Welcome to LUXE" }) {
  return (
    <motion.div
      className="fixed inset-0 z-[120] grid place-items-center bg-ink-950"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* Gold sweep */}
      <motion.div
        className="absolute inset-0 bg-gold-gradient"
        initial={{ scaleY: 0 }}
        animate={{ scaleY: [0, 1, 1, 0] }}
        transition={{ duration: 1.4, times: [0, 0.35, 0.65, 1], ease: [0.76, 0, 0.24, 1] }}
        style={{ originY: 1 }}
      />
      <motion.div
        className="relative z-10 flex flex-col items-center gap-4"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        <div className="grid h-16 w-16 place-items-center rounded-full bg-ink-950 text-gold-500">
          <Check size={34} strokeWidth={3} />
        </div>
        <p className="font-display text-3xl text-ink-950">{label}</p>
      </motion.div>
    </motion.div>
  );
}
