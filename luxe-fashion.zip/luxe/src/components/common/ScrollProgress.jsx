import { motion, useScroll, useSpring } from "framer-motion";

/** A slim gold bar pinned to the top that fills as you scroll the page. */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 30,
    restDelta: 0.001,
  });

  return (
    <motion.div
      className="fixed left-0 top-0 z-[80] h-[3px] w-full origin-left bg-gold-gradient"
      style={{ scaleX }}
      aria-hidden
    />
  );
}
