import { Component } from "react";

/**
 * A minimal error boundary. Used to isolate risky subtrees (e.g. the WebGL
 * canvas) so a failure there can never blank the entire site — it simply
 * renders the provided `fallback` instead.
 */
export class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error) {
    // In production you'd forward this to your monitoring service.
    if (import.meta.env.DEV) console.warn("ErrorBoundary caught:", error);
  }

  render() {
    if (this.state.hasError) return this.props.fallback ?? null;
    return this.props.children;
  }
}
