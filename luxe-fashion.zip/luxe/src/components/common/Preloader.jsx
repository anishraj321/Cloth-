import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Cinematic preloader: the LUXE wordmark reveals letter-by-letter behind a
 * gold sweep while a counter races to 100, then the curtain lifts.
 */
export function Preloader({ onDone }) {
  const [count, setCount] = useState(0);
  const [visible, setVisible] = useState(true);
  const word = "LUXE".split("");

  useEffect(() => {
    let raf;
    const start = performance.now();
    const duration = 1900;
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration);
      // easeOutExpo for a luxurious deceleration
      const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
      setCount(Math.round(eased * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
      else {
        setTimeout(() => {
          setVisible(false);
          setTimeout(() => onDone?.(), 900);
        }, 300);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 z-[100] grid place-items-center bg-ink-950"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Curtain panels that split apart on exit */}
          <motion.div
            className="absolute inset-y-0 left-0 w-1/2 bg-ink-950 z-10"
            exit={{ x: "-100%" }}
            transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
          />
          <motion.div
            className="absolute inset-y-0 right-0 w-1/2 bg-ink-950 z-10"
            exit={{ x: "100%" }}
            transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
          />

          <div className="relative z-20 flex flex-col items-center">
            <div className="flex overflow-hidden">
              {word.map((letter, i) => (
                <motion.span
                  key={i}
                  className="font-display text-6xl md:text-8xl font-bold text-gold-gradient"
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{
                    delay: 0.15 + i * 0.08,
                    duration: 0.7,
                    ease: [0.33, 1, 0.68, 1],
                  }}
                >
                  {letter}
                </motion.span>
              ))}
            </div>

            <motion.div
              className="mt-6 h-px w-40 overflow-hidden bg-white/10"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.4, duration: 1.5 }}
            >
              <motion.div
                className="h-full bg-gold-gradient"
                style={{ width: `${count}%` }}
              />
            </motion.div>

            <div className="mt-4 flex w-40 items-center justify-between font-mono text-[10px] uppercase tracking-luxe text-ink-400">
              <span>Loading</span>
              <span className="tabular-nums text-gold-500">{count}%</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
