import { TextReveal } from "./TextReveal";
import { Reveal } from "./Reveal";
import { cn } from "@/lib/utils";

/** Standardised section header: gold eyebrow, serif title, optional subtitle. */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  className,
}) {
  const alignment =
    align === "center"
      ? "items-center text-center mx-auto"
      : align === "right"
      ? "items-end text-right ml-auto"
      : "items-start text-left";

  return (
    <div className={cn("flex max-w-2xl flex-col gap-4", alignment, className)}>
      {eyebrow && (
        <Reveal>
          <span className="eyebrow flex items-center gap-3">
            <span className="h-px w-8 bg-gold-500/60" />
            {eyebrow}
          </span>
        </Reveal>
      )}
      <TextReveal
        text={title}
        className="font-display text-4xl font-semibold leading-[1.05] md:text-5xl"
      />
      {subtitle && (
        <Reveal delay={0.15}>
          <p className="max-w-xl text-sm leading-relaxed text-ink-300 md:text-base">
            {subtitle}
          </p>
        </Reveal>
      )}
    </div>
  );
}
