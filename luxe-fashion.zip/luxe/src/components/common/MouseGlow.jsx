import { motion, useMotionValue, useSpring, useMotionTemplate } from "framer-motion";
import { useEffect } from "react";
import { useHasFinePointer } from "@/hooks/useMediaQuery";

/**
 * A soft golden glow that trails the pointer across the whole page — the
 * ambient "spotlight" that gives the site its cinematic depth.
 */
export function MouseGlow() {
  const finePointer = useHasFinePointer();
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 60, damping: 20 });
  const sy = useSpring(y, { stiffness: 60, damping: 20 });

  useEffect(() => {
    if (!finePointer) return;
    const move = (e) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    window.addEventListener("mousemove", move, { passive: true });
    return () => window.removeEventListener("mousemove", move);
  }, [finePointer, x, y]);

  const background = useMotionTemplate`radial-gradient(340px circle at ${sx}px ${sy}px, rgba(212,175,55,0.10), transparent 70%)`;

  if (!finePointer) return null;

  return (
    <motion.div
      className="pointer-events-none fixed inset-0 z-[5]"
      style={{ background }}
      aria-hidden
    />
  );
}
