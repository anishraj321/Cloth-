import { useState } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * AuthField — a floating-label input with a gold focus underline that animates
 * as you type, plus an optional password reveal toggle and inline error.
 */
export function AuthField({
  label,
  type = "text",
  value,
  onChange,
  error,
  icon: Icon,
  autoComplete,
  name,
}) {
  const [focused, setFocused] = useState(false);
  const [show, setShow] = useState(false);
  const isPassword = type === "password";
  const active = focused || value?.length > 0;

  return (
    <div className="relative">
      <div
        className={cn(
          "relative flex items-center rounded-xl border bg-white/5 transition-colors",
          error ? "border-red-400/70" : focused ? "border-gold-500/70" : "border-white/10"
        )}
      >
        {Icon && (
          <Icon size={18} className={cn("ml-4 transition-colors", focused ? "text-gold-500" : "text-ink-400")} />
        )}
        <div className="relative flex-1">
          <motion.label
            className={cn(
              "pointer-events-none absolute left-3 origin-left text-ink-400",
              active ? "top-1.5 text-[10px] font-mono uppercase tracking-widest text-gold-500" : "top-1/2 -translate-y-1/2 text-sm"
            )}
            animate={{ y: active ? 0 : 0 }}
          >
            {label}
          </motion.label>
          <input
            name={name}
            type={isPassword ? (show ? "text" : "password") : type}
            value={value}
            onChange={onChange}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            autoComplete={autoComplete}
            className="w-full bg-transparent px-3 pb-2 pt-6 text-sm outline-none"
          />
        </div>
        {isPassword && (
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            className="mr-4 text-ink-400 transition-colors hover:text-white"
            aria-label={show ? "Hide password" : "Show password"}
          >
            {show ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        )}
      </div>
      {/* Animated underline */}
      <motion.span
        className="absolute -bottom-px left-3 right-3 h-0.5 origin-left bg-gold-gradient"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: focused ? 1 : 0 }}
        transition={{ duration: 0.35 }}
      />
      {error && <p className="mt-1.5 text-xs text-red-400">{error}</p>}
    </div>
  );
}
