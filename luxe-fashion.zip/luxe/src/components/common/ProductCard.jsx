import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { Heart, Eye, ShoppingBag } from "lucide-react";
import { LazyImage } from "./LazyImage";
import { Rating } from "./Rating";
import { Badge } from "@/components/ui/badge";
import { useWishlist } from "@/context/WishlistContext";
import { useCart } from "@/context/CartContext";
import { useHasFinePointer } from "@/hooks/useMediaQuery";
import { cn, formatPrice } from "@/lib/utils";

/**
 * ProductCard — a floating, 3D-tilting card. On hover it lifts, the image
 * cross-fades to its second shot, and quick actions (wishlist / quick-view /
 * add-to-bag) fade up. The whole card tilts toward the cursor in 3D.
 */
export function ProductCard({ product, index = 0, onQuickView }) {
  const finePointer = useHasFinePointer();
  const ref = useRef(null);
  const [hover, setHover] = useState(false);
  const { has, toggle } = useWishlist();
  const { addItem } = useCart();
  const wished = has(product.id);

  // 3D tilt
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rotateX = useSpring(useTransform(my, [0, 1], [8, -8]), {
    stiffness: 200,
    damping: 20,
  });
  const rotateY = useSpring(useTransform(mx, [0, 1], [-8, 8]), {
    stiffness: 200,
    damping: 20,
  });

  const handleMove = (e) => {
    if (!finePointer) return;
    const rect = ref.current.getBoundingClientRect();
    mx.set((e.clientX - rect.left) / rect.width);
    my.set((e.clientY - rect.top) / rect.height);
  };
  const handleLeave = () => {
    mx.set(0.5);
    my.set(0.5);
    setHover(false);
  };

  const displayPrice = product.salePrice || product.price;
  const discount = product.salePrice
    ? Math.round((1 - product.salePrice / product.price) * 100)
    : 0;

  return (
    <motion.div
      ref={ref}
      className="perspective group relative"
      onMouseMove={handleMove}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={handleLeave}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-8% 0px" }}
      transition={{ duration: 0.6, delay: (index % 4) * 0.08, ease: [0.22, 1, 0.36, 1] }}
    >
      <motion.div
        style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
        className="relative"
      >
        {/* Media */}
        <div className="relative aspect-[3/4] overflow-hidden rounded-2xl glass">
          <Link to={`/product/${product.id}`} aria-label={product.name}>
            <LazyImage
              src={product.images[0]}
              alt={product.name}
              className="absolute inset-0"
              imgClassName={cn(
                "transition-transform duration-[900ms] ease-out",
                hover ? "scale-110" : "scale-100"
              )}
            />
            {/* Second image cross-fade */}
            {product.images[1] && (
              <LazyImage
                src={product.images[1]}
                alt=""
                className={cn(
                  "absolute inset-0 transition-opacity duration-700",
                  hover ? "opacity-100" : "opacity-0"
                )}
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" />
          </Link>

          {/* Badges */}
          <div className="absolute left-3 top-3 flex flex-col gap-2">
            {product.badge && (
              <Badge variant={product.salePrice ? "sale" : "gold"}>
                {discount ? `-${discount}%` : product.badge}
              </Badge>
            )}
          </div>

          {/* Wishlist */}
          <button
            onClick={() => toggle(product.id)}
            aria-label="Add to wishlist"
            className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full glass-strong transition-transform hover:scale-110 active:scale-95"
          >
            <Heart
              size={17}
              className={cn(
                "transition-colors",
                wished ? "fill-gold-500 text-gold-500" : "text-white"
              )}
            />
          </button>

          {/* Quick actions */}
          <div
            className={cn(
              "absolute inset-x-3 bottom-3 flex items-center gap-2 transition-all duration-500",
              hover
                ? "translate-y-0 opacity-100"
                : "pointer-events-none translate-y-4 opacity-0"
            )}
          >
            <button
              onClick={() => addItem(product, { size: product.sizes[0], color: product.colors[0]?.name })}
              className="flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-gold-gradient text-xs font-semibold text-ink-950 shadow-gold transition-transform hover:-translate-y-0.5"
            >
              <ShoppingBag size={15} /> Add to Bag
            </button>
            {onQuickView && (
              <button
                onClick={() => onQuickView(product)}
                aria-label="Quick view"
                className="grid h-11 w-11 place-items-center rounded-full glass-strong transition-transform hover:scale-105"
              >
                <Eye size={17} />
              </button>
            )}
          </div>
        </div>

        {/* Meta */}
        <div className="mt-4 flex items-start justify-between gap-3" style={{ transform: "translateZ(30px)" }}>
          <div className="min-w-0">
            <p className="font-mono text-[10px] uppercase tracking-widest text-gold-500">
              {product.subcategory}
            </p>
            <Link
              to={`/product/${product.id}`}
              className="mt-1 block truncate font-display text-lg leading-tight transition-colors hover:text-gold-500"
            >
              {product.name}
            </Link>
            <Rating value={product.rating} className="mt-1.5" size={12} />
          </div>
          <div className="text-right">
            <p className="font-display text-lg text-gold-gradient">
              {formatPrice(displayPrice)}
            </p>
            {product.salePrice && (
              <p className="text-xs text-ink-400 line-through">
                {formatPrice(product.price)}
              </p>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
