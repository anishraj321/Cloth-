import { useState } from "react";
import { ProductCard } from "./ProductCard";
import { QuickView } from "@/components/product/QuickView";
import { cn } from "@/lib/utils";

/**
 * ProductGrid — renders product cards in a responsive grid and owns the
 * shared Quick View modal state so any card can open it.
 */
export function ProductGrid({ products, className, columns = 4 }) {
  const [quick, setQuick] = useState(null);
  const cols = {
    2: "sm:grid-cols-2",
    3: "sm:grid-cols-2 lg:grid-cols-3",
    4: "sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
  }[columns];

  return (
    <>
      <div className={cn("grid grid-cols-1 gap-6 md:gap-8", cols, className)}>
        {products.map((p, i) => (
          <ProductCard key={p.id} product={p} index={i} onQuickView={setQuick} />
        ))}
      </div>
      <QuickView product={quick} onClose={() => setQuick(null)} />
    </>
  );
}
