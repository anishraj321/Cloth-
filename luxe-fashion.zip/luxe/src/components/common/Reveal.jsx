import { motion } from "framer-motion";

const directions = {
  up: { y: 40, x: 0 },
  down: { y: -40, x: 0 },
  left: { x: 40, y: 0 },
  right: { x: -40, y: 0 },
  none: { x: 0, y: 0 },
};

/**
 * Reveal — a generic scroll-into-view wrapper. Fades + slides children in from
 * a chosen direction with an optional stagger index for grids.
 */
export function Reveal({
  children,
  direction = "up",
  delay = 0,
  index = 0,
  className = "",
  once = true,
  duration = 0.7,
}) {
  const offset = directions[direction] || directions.up;
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, ...offset }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once, margin: "-12% 0px" }}
      transition={{
        duration,
        delay: delay + index * 0.08,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      {children}
    </motion.div>
  );
}
