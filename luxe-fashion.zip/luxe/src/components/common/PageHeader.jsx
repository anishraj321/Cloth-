import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { TextReveal } from "./TextReveal";
import { Reveal } from "./Reveal";
import { ParticleBackground } from "./ParticleBackground";

/** Shared inner-page hero with breadcrumb, big serif title, and particles. */
export function PageHeader({ title, subtitle, crumbs = [] }) {
  return (
    <header className="relative overflow-hidden pt-36 pb-16">
      <div className="absolute inset-0 bg-radial-fade" />
      <ParticleBackground density={30} />
      <div className="container relative">
        <Reveal>
          <nav className="mb-6 flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-ink-400">
            <Link to="/" className="transition-colors hover:text-gold-500">
              Home
            </Link>
            {crumbs.map((c) => (
              <span key={c.label} className="flex items-center gap-2">
                <ChevronRight size={12} />
                {c.to ? (
                  <Link to={c.to} className="transition-colors hover:text-gold-500">
                    {c.label}
                  </Link>
                ) : (
                  <span className="text-gold-500">{c.label}</span>
                )}
              </span>
            ))}
          </nav>
        </Reveal>
        <TextReveal
          text={title}
          className="font-display text-5xl font-semibold md:text-7xl"
        />
        {subtitle && (
          <Reveal delay={0.15}>
            <p className="mt-4 max-w-xl text-ink-300">{subtitle}</p>
          </Reveal>
        )}
      </div>
    </header>
  );
}
