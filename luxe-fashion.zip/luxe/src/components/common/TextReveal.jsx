import { motion } from "framer-motion";

/**
 * TextReveal — splits a line into words and slides each up from behind a mask
 * when it scrolls into view. Great for cinematic headlines.
 */
export function TextReveal({
  text,
  as: Tag = "span",
  className = "",
  delay = 0,
  stagger = 0.06,
  once = true,
}) {
  const words = text.split(" ");
  const container = {
    hidden: {},
    visible: {
      transition: { staggerChildren: stagger, delayChildren: delay },
    },
  };
  const child = {
    hidden: { y: "115%" },
    visible: {
      y: 0,
      transition: { duration: 0.8, ease: [0.33, 1, 0.68, 1] },
    },
  };

  return (
    <motion.span
      as={Tag}
      variants={container}
      initial="hidden"
      whileInView="visible"
      viewport={{ once, margin: "-10% 0px" }}
      className={`inline-flex flex-wrap ${className}`}
      aria-label={text}
    >
      {words.map((word, i) => (
        <span key={i} className="inline-flex overflow-hidden pb-[0.12em] pr-[0.28em]">
          <motion.span variants={child} className="inline-block" aria-hidden>
            {word}
          </motion.span>
        </span>
      ))}
    </motion.span>
  );
}
