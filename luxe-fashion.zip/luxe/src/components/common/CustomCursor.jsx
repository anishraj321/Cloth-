import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useHasFinePointer } from "@/hooks/useMediaQuery";

/**
 * A two-part custom cursor: an instant gold dot and a lagging ring that
 * springs behind it. The ring grows and the dot hides when hovering
 * interactive elements (anything with [data-cursor="hover"], a, or button).
 */
export function CustomCursor() {
  const finePointer = useHasFinePointer();
  const [hovering, setHovering] = useState(false);
  const [hidden, setHidden] = useState(true);
  const [clicking, setClicking] = useState(false);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const ringX = useSpring(x, { stiffness: 320, damping: 28, mass: 0.6 });
  const ringY = useSpring(y, { stiffness: 320, damping: 28, mass: 0.6 });
  const rafPending = useRef(false);

  useEffect(() => {
    if (!finePointer) {
      document.body.classList.remove("custom-cursor");
      return;
    }
    document.body.classList.add("custom-cursor");

    const move = (e) => {
      if (rafPending.current) return;
      rafPending.current = true;
      requestAnimationFrame(() => {
        x.set(e.clientX);
        y.set(e.clientY);
        rafPending.current = false;
      });
      setHidden(false);
      const el = e.target;
      const interactive = el.closest?.(
        'a, button, [role="button"], input, textarea, select, [data-cursor="hover"]'
      );
      setHovering(Boolean(interactive));
    };
    const down = () => setClicking(true);
    const up = () => setClicking(false);
    const leave = () => setHidden(true);

    window.addEventListener("mousemove", move, { passive: true });
    window.addEventListener("mousedown", down);
    window.addEventListener("mouseup", up);
    document.addEventListener("mouseleave", leave);
    return () => {
      document.body.classList.remove("custom-cursor");
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mousedown", down);
      window.removeEventListener("mouseup", up);
      document.removeEventListener("mouseleave", leave);
    };
  }, [finePointer, x, y]);

  if (!finePointer) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[90]" aria-hidden>
      {/* Lagging ring */}
      <motion.div
        className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-gold-500/70"
        style={{ left: ringX, top: ringY }}
        animate={{
          width: hovering ? 56 : 34,
          height: hovering ? 56 : 34,
          opacity: hidden ? 0 : hovering ? 1 : 0.6,
          backgroundColor: hovering
            ? "rgba(212,175,55,0.10)"
            : "rgba(212,175,55,0)",
          scale: clicking ? 0.85 : 1,
        }}
        transition={{ type: "spring", stiffness: 260, damping: 22 }}
      />
      {/* Instant dot */}
      <motion.div
        className="absolute h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold-500"
        style={{ left: x, top: y }}
        animate={{ opacity: hidden || hovering ? 0 : 1, scale: clicking ? 2 : 1 }}
        transition={{ duration: 0.15 }}
      />
    </div>
  );
}
