import { motion } from "framer-motion";

/**
 * Wraps each routed page so it fades / lifts in on mount and out on unmount
 * (paired with <AnimatePresence> in App). Keeps transitions consistent.
 */
export function PageTransition({ children }) {
  return (
    <motion.main
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -16 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="min-h-screen"
    >
      {children}
    </motion.main>
  );
}
