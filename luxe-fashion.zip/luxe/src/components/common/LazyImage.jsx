import { useState } from "react";
import { cn } from "@/lib/utils";

/**
 * LazyImage — native lazy-loading with a shimmering skeleton and a soft
 * blur-up fade once the image decodes. Falls back gracefully on error.
 */
export function LazyImage({ src, alt = "", className, imgClassName, ...props }) {
  const [loaded, setLoaded] = useState(false);
  const [errored, setErrored] = useState(false);

  return (
    <div className={cn("relative overflow-hidden", className)}>
      {!loaded && !errored && (
        <div className="absolute inset-0 skeleton" aria-hidden />
      )}
      {errored ? (
        <div className="absolute inset-0 grid place-items-center bg-ink-900 text-ink-500">
          <span className="font-mono text-xs tracking-widest">LUXE</span>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          loading="lazy"
          decoding="async"
          onLoad={() => setLoaded(true)}
          onError={() => setErrored(true)}
          className={cn(
            "h-full w-full object-cover transition-all duration-700 ease-out",
            loaded ? "scale-100 blur-0 opacity-100" : "scale-105 blur-xl opacity-0",
            imgClassName
          )}
          {...props}
        />
      )}
    </div>
  );
}
