import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

/** Gold star rating (supports halves visually via fill). */
export function Rating({ value = 0, count, size = 14, className }) {
  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div className="flex">
        {[1, 2, 3, 4, 5].map((i) => (
          <Star
            key={i}
            size={size}
            className={cn(
              i <= Math.round(value)
                ? "fill-gold-500 text-gold-500"
                : "fill-transparent text-ink-400"
            )}
          />
        ))}
      </div>
      {count != null && (
        <span className="text-xs text-ink-400">
          {value.toFixed(1)} ({count})
        </span>
      )}
    </div>
  );
}
