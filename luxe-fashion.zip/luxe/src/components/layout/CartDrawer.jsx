import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus, Minus, Trash2, ShoppingBag } from "lucide-react";
import { LazyImage } from "@/components/common/LazyImage";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { useLockBodyScroll } from "@/hooks/useLockBodyScroll";
import { formatPrice } from "@/lib/utils";

/** Slide-in shopping bag summarising the cart with quantity controls. */
export function CartDrawer({ open, onClose }) {
  const { items, setQty, removeItem, totals } = useCart();
  useLockBodyScroll(open);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[85]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="absolute inset-0 bg-ink-950/70 backdrop-blur-sm" onClick={onClose} />
          <motion.aside
            className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col glass-strong"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 32 }}
          >
            <header className="flex items-center justify-between border-b border-white/10 p-6">
              <h3 className="font-display text-2xl">
                Your Bag <span className="text-gold-500">({items.length})</span>
              </h3>
              <button
                onClick={onClose}
                className="grid h-10 w-10 place-items-center rounded-full glass transition-transform hover:rotate-90"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </header>

            {items.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
                <div className="grid h-20 w-20 place-items-center rounded-full glass">
                  <ShoppingBag className="text-gold-500" />
                </div>
                <p className="text-ink-300">Your bag is beautifully empty.</p>
                <Button variant="outline" onClick={onClose}>
                  Continue shopping
                </Button>
              </div>
            ) : (
              <>
                <div className="flex-1 space-y-4 overflow-y-auto p-6 no-scrollbar">
                  {items.map((line) => (
                    <motion.div
                      key={line.key}
                      layout
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="flex gap-4"
                    >
                      <LazyImage src={line.image} alt={line.name} className="h-24 w-20 shrink-0 rounded-xl" />
                      <div className="flex flex-1 flex-col">
                        <div className="flex justify-between gap-2">
                          <p className="font-display text-base leading-tight">{line.name}</p>
                          <button onClick={() => removeItem(line.key)} aria-label="Remove">
                            <Trash2 size={16} className="text-ink-400 hover:text-white" />
                          </button>
                        </div>
                        <p className="text-xs text-ink-400">
                          {[line.size, line.color].filter(Boolean).join(" · ")}
                        </p>
                        <div className="mt-auto flex items-center justify-between">
                          <div className="flex items-center gap-3 rounded-full border border-white/10 px-2 py-1">
                            <button onClick={() => setQty(line.key, line.qty - 1)} aria-label="Decrease">
                              <Minus size={14} />
                            </button>
                            <span className="w-4 text-center text-sm tabular-nums">{line.qty}</span>
                            <button onClick={() => setQty(line.key, line.qty + 1)} aria-label="Increase">
                              <Plus size={14} />
                            </button>
                          </div>
                          <span className="text-gold-500">{formatPrice(line.price * line.qty)}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <footer className="space-y-4 border-t border-white/10 p-6">
                  <div className="flex justify-between text-sm text-ink-300">
                    <span>Subtotal</span>
                    <span className="text-white">{formatPrice(totals.subtotal)}</span>
                  </div>
                  <p className="text-xs text-ink-400">
                    Shipping & taxes calculated at checkout.
                  </p>
                  <Link to="/cart" onClick={onClose}>
                    <Button variant="glass" className="w-full">View Bag</Button>
                  </Link>
                  <Link to="/checkout" onClick={onClose}>
                    <Button className="w-full">Checkout · {formatPrice(totals.total)}</Button>
                  </Link>
                </footer>
              </>
            )}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
