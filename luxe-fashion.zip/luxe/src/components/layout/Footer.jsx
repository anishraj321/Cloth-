import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Instagram, Twitter, Facebook, Youtube, ArrowRight, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { MagneticButton } from "@/components/common/MagneticButton";

const columns = [
  {
    title: "Shop",
    links: [
      { label: "New Arrivals", to: "/new-arrivals" },
      { label: "Best Sellers", to: "/best-sellers" },
      { label: "Women", to: "/women" },
      { label: "Men", to: "/men" },
      { label: "Sale", to: "/sale" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", to: "/about" },
      { label: "Journal", to: "/blog" },
      { label: "Contact", to: "/contact" },
      { label: "FAQ", to: "/faq" },
    ],
  },
  {
    title: "Account",
    links: [
      { label: "Sign In", to: "/login" },
      { label: "Register", to: "/register" },
      { label: "Wishlist", to: "/wishlist" },
      { label: "Cart", to: "/cart" },
    ],
  },
];

const socials = [Instagram, Twitter, Facebook, Youtube];

export function Footer() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (!email.includes("@")) return;
    setSent(true);
    setEmail("");
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <footer className="relative mt-32 overflow-hidden border-t border-white/10">
      <div className="pointer-events-none absolute inset-0 bg-radial-fade" />
      <div className="container relative py-16">
        {/* Newsletter */}
        <div className="grid gap-10 border-b border-white/10 pb-14 lg:grid-cols-2 lg:items-end">
          <div>
            <h3 className="font-display text-4xl md:text-5xl">
              Join the <span className="text-gold-gradient">inner circle</span>
            </h3>
            <p className="mt-3 max-w-md text-ink-300">
              Early access to collections, private sales, and the LUXE journal.
              No noise — only beautiful things.
            </p>
          </div>
          <form onSubmit={submit} className="flex gap-3">
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="h-14 flex-1"
              aria-label="Email address"
            />
            <MagneticButton>
              <button
                type="submit"
                className="grid h-14 w-14 place-items-center rounded-xl bg-gold-gradient text-ink-950 shadow-gold transition-transform"
                aria-label="Subscribe"
              >
                {sent ? <Check /> : <ArrowRight />}
              </button>
            </MagneticButton>
          </form>
        </div>

        {/* Links */}
        <div className="grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="font-display text-3xl font-bold">
              LU<span className="text-gold-gradient">X</span>E
            </Link>
            <p className="mt-4 max-w-xs text-sm text-ink-400">
              A modern fashion house crafting timeless, cinematic pieces since 2014.
            </p>
            <div className="mt-6 flex gap-3">
              {socials.map((Icon, i) => (
                <motion.a
                  key={i}
                  href="#"
                  whileHover={{ y: -4 }}
                  className="grid h-10 w-10 place-items-center rounded-full glass transition-colors hover:text-gold-500"
                  aria-label="Social link"
                >
                  <Icon size={17} />
                </motion.a>
              ))}
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="font-mono text-xs uppercase tracking-widest text-gold-500">
                {col.title}
              </h4>
              <ul className="mt-5 space-y-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      to={l.to}
                      className="group inline-flex items-center gap-1 text-sm text-ink-300 transition-colors hover:text-white"
                    >
                      <span className="h-px w-0 bg-gold-500 transition-all duration-300 group-hover:w-4" />
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 text-xs text-ink-400 md:flex-row">
          <p>© {new Date().getFullYear()} LUXE Fashion House. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">Terms</a>
            <a href="#" className="hover:text-white">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
