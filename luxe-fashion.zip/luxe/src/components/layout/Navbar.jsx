import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from "framer-motion";
import { Search, Heart, ShoppingBag, Menu, X, Sun, Moon, User } from "lucide-react";
import { MagneticButton } from "@/components/common/MagneticButton";
import { SearchOverlay } from "./SearchOverlay";
import { CartDrawer } from "./CartDrawer";
import { useTheme } from "@/context/ThemeContext";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";
import { useLockBodyScroll } from "@/hooks/useLockBodyScroll";
import { cn } from "@/lib/utils";

const links = [
  { to: "/shop", label: "Shop" },
  { to: "/categories", label: "Categories" },
  { to: "/men", label: "Men" },
  { to: "/women", label: "Women" },
  { to: "/new-arrivals", label: "New" },
  { to: "/best-sellers", label: "Bestsellers" },
  { to: "/sale", label: "Sale" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { count } = useCart();
  const { count: wishCount } = useWishlist();
  const { scrollY } = useScroll();
  const location = useLocation();

  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 40));
  useLockBodyScroll(menuOpen);

  // Close the mobile menu whenever the route changes.
  useEffect(() => setMenuOpen(false), [location.pathname]);

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className={cn(
          "fixed inset-x-0 top-0 z-[70] transition-all duration-500",
          scrolled ? "py-3" : "py-5"
        )}
      >
        <div
          className={cn(
            "container flex items-center justify-between rounded-full px-5 transition-all duration-500",
            scrolled ? "glass-strong py-2.5 shadow-glass" : "py-1"
          )}
        >
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2" data-cursor="hover">
            <span className="font-display text-2xl font-bold tracking-tight">
              LU<span className="text-gold-gradient">X</span>E
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 lg:flex">
            {links.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  cn(
                    "relative px-4 py-2 text-sm transition-colors hover:text-gold-500",
                    isActive ? "text-gold-500" : "text-current"
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    {link.label}
                    {isActive && (
                      <motion.span
                        layoutId="nav-underline"
                        className="absolute inset-x-3 -bottom-0.5 h-px bg-gold-gradient"
                      />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-1">
            <IconBtn onClick={() => setSearchOpen(true)} label="Search">
              <Search size={19} />
            </IconBtn>
            <IconBtn onClick={toggleTheme} label="Toggle theme">
              <AnimatePresence mode="wait" initial={false}>
                <motion.span
                  key={theme}
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {theme === "dark" ? <Sun size={19} /> : <Moon size={19} />}
                </motion.span>
              </AnimatePresence>
            </IconBtn>
            <Link to="/login" className="hidden sm:block">
              <IconBtn label="Account">
                <User size={19} />
              </IconBtn>
            </Link>
            <Link to="/wishlist" className="relative">
              <IconBtn label="Wishlist">
                <Heart size={19} />
                <Counter value={wishCount} />
              </IconBtn>
            </Link>
            <button
              onClick={() => setCartOpen(true)}
              className="relative grid h-10 w-10 place-items-center rounded-full transition-colors hover:bg-white/10"
              aria-label="Cart"
            >
              <ShoppingBag size={19} />
              <Counter value={count} />
            </button>
            <button
              onClick={() => setMenuOpen(true)}
              className="grid h-10 w-10 place-items-center rounded-full transition-colors hover:bg-white/10 lg:hidden"
              aria-label="Menu"
            >
              <Menu size={20} />
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="fixed inset-0 z-[75] lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-md" onClick={() => setMenuOpen(false)} />
            <motion.nav
              className="absolute right-0 top-0 flex h-full w-4/5 max-w-sm flex-col gap-2 glass-strong p-8 pt-24"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 280, damping: 30 }}
            >
              <button
                onClick={() => setMenuOpen(false)}
                className="absolute right-6 top-8 grid h-10 w-10 place-items-center rounded-full glass"
                aria-label="Close menu"
              >
                <X size={18} />
              </button>
              {links.map((link, i) => (
                <motion.div
                  key={link.to}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i }}
                >
                  <NavLink
                    to={link.to}
                    className="block border-b border-white/10 py-4 font-display text-2xl transition-colors hover:text-gold-500"
                  >
                    {link.label}
                  </NavLink>
                </motion.div>
              ))}
              <div className="mt-6 flex gap-3">
                <Link to="/login" className="flex-1">
                  <MagneticButton className="w-full">
                    <span className="block w-full rounded-full border border-gold-500/40 py-3 text-center text-sm">
                      Sign In
                    </span>
                  </MagneticButton>
                </Link>
              </div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </>
  );
}

function IconBtn({ children, label, ...props }) {
  return (
    <button
      className="relative grid h-10 w-10 place-items-center rounded-full transition-colors hover:bg-white/10"
      aria-label={label}
      {...props}
    >
      {children}
    </button>
  );
}

function Counter({ value }) {
  if (!value) return null;
  return (
    <motion.span
      key={value}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-gold-gradient px-1 text-[10px] font-bold text-ink-950"
    >
      {value}
    </motion.span>
  );
}
