import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X } from "lucide-react";
import { products } from "@/data/products";
import { LazyImage } from "@/components/common/LazyImage";
import { useLockBodyScroll } from "@/hooks/useLockBodyScroll";
import { formatPrice } from "@/lib/utils";

const suggestions = ["Trench", "Silk", "Cashmere", "Gold", "Tuxedo"];

/** Full-screen search with live, fuzzy-ish filtering over the catalogue. */
export function SearchOverlay({ open, onClose }) {
  const [q, setQ] = useState("");
  useLockBodyScroll(open);

  useEffect(() => {
    if (!open) setQ("");
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const results = useMemo(() => {
    if (!q.trim()) return [];
    const term = q.toLowerCase();
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(term) ||
        p.subcategory.toLowerCase().includes(term) ||
        p.category.toLowerCase().includes(term)
    );
  }, [q]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[96]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="absolute inset-0 bg-ink-950/85 backdrop-blur-xl" onClick={onClose} />
          <motion.div
            className="relative mx-auto mt-24 w-full max-w-2xl px-6"
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -30, opacity: 0 }}
          >
            <div className="flex items-center gap-3 border-b border-gold-500/40 pb-4">
              <Search className="text-gold-500" />
              <input
                autoFocus
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search the collection…"
                className="w-full bg-transparent font-display text-2xl outline-none placeholder:text-ink-500"
              />
              <button onClick={onClose} aria-label="Close search">
                <X className="text-ink-400 transition-colors hover:text-white" />
              </button>
            </div>

            {!q && (
              <div className="mt-6 flex flex-wrap gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => setQ(s)}
                    className="rounded-full border border-white/10 px-4 py-1.5 text-sm text-ink-300 transition-colors hover:border-gold-500/50 hover:text-gold-500"
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}

            <div className="mt-6 max-h-[50vh] space-y-2 overflow-y-auto no-scrollbar">
              {results.map((p) => (
                <Link
                  key={p.id}
                  to={`/product/${p.id}`}
                  onClick={onClose}
                  className="flex items-center gap-4 rounded-xl p-2 transition-colors hover:bg-white/5"
                >
                  <LazyImage src={p.images[0]} alt="" className="h-16 w-14 rounded-lg" />
                  <div className="flex-1">
                    <p className="font-display text-lg">{p.name}</p>
                    <p className="text-xs text-ink-400">{p.subcategory}</p>
                  </div>
                  <span className="text-gold-500">{formatPrice(p.salePrice || p.price)}</span>
                </Link>
              ))}
              {q && results.length === 0 && (
                <p className="py-8 text-center text-ink-400">
                  No pieces found for "{q}".
                </p>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
