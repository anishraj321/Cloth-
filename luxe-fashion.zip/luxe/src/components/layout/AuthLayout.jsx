import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { ParticleBackground } from "@/components/common/ParticleBackground";
import { LazyImage } from "@/components/common/LazyImage";

const MODEL_IMG =
  "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1000&q=80";

/**
 * The signature auth stage. On the left, a fashion model "walks" onto screen
 * carrying shopping bags under luxury lighting and floating gold particles.
 * On the right, the glass auth card slides in. Children render the form.
 */
export function AuthLayout({ title, subtitle, children, footer }) {
  return (
    <section className="relative grid min-h-screen lg:grid-cols-2">
      {/* Ambient particles across the whole stage */}
      <ParticleBackground density={45} className="z-0" />

      {/* Back link */}
      <Link
        to="/"
        className="absolute left-6 top-6 z-30 inline-flex items-center gap-2 rounded-full glass px-4 py-2 text-sm transition-colors hover:text-gold-500"
      >
        <ArrowLeft size={16} /> Home
      </Link>

      {/* Cinematic model panel */}
      <div className="relative hidden overflow-hidden lg:block">
        <div className="absolute inset-0 bg-gradient-to-tr from-gold-500/10 via-transparent to-transparent" />
        {/* Spotlight */}
        <div className="pointer-events-none absolute left-1/2 top-0 h-[70%] w-[60%] -translate-x-1/2 rounded-full bg-gold-500/15 blur-[120px]" />

        <motion.div
          className="absolute inset-0 flex items-end justify-center"
          initial={{ x: -140, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        >
          {/* Subtle walking bob */}
          <motion.div
            className="h-[92%] w-[85%]"
            animate={{ y: [0, -10, 0] }}
            transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut" }}
          >
            <div className="relative h-full overflow-hidden rounded-t-[3rem] border border-white/10">
              <LazyImage src={MODEL_IMG} alt="LUXE model" className="h-full w-full" imgClassName="object-cover object-top" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-transparent" />
              <div className="absolute bottom-10 left-10 max-w-xs">
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1 }}
                  className="font-display text-4xl leading-tight"
                >
                  Step into the <span className="text-gold-gradient">house of LUXE</span>
                </motion.p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Form panel */}
      <div className="relative z-10 grid place-items-center px-6 py-24">
        <motion.div
          className="w-full max-w-md rounded-3xl glass-strong p-8 md:p-10"
          initial={{ x: 120, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        >
          <Link to="/" className="mb-8 inline-block font-display text-3xl font-bold">
            LU<span className="text-gold-gradient">X</span>E
          </Link>
          <h1 className="font-display text-3xl">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-ink-300">{subtitle}</p>}
          <div className="mt-8">{children}</div>
          {footer && <div className="mt-6 text-center text-sm text-ink-400">{footer}</div>}
        </motion.div>
      </div>
    </section>
  );
}
