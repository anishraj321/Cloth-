import { cn } from "@/lib/utils";

/** Shimmering placeholder used while content / images load. */
export function Skeleton({ className, ...props }) {
  return <div className={cn("skeleton", className)} {...props} />;
}
