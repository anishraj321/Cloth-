import { cva } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-3 py-1 text-[10px] font-mono uppercase tracking-widest",
  {
    variants: {
      variant: {
        gold: "bg-gold-gradient text-ink-950 font-semibold",
        outline: "border border-gold-500/50 text-gold-500",
        dark: "bg-ink-950/80 text-white backdrop-blur",
        sale: "bg-[#7a1626] text-white",
        glass: "glass text-current",
      },
    },
    defaultVariants: { variant: "gold" },
  }
);

export function Badge({ className, variant, ...props }) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
