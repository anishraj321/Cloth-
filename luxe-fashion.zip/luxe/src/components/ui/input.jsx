import { forwardRef } from "react";
import { cn } from "@/lib/utils";

const Input = forwardRef(({ className, type = "text", ...props }, ref) => (
  <input
    ref={ref}
    type={type}
    className={cn(
      "flex h-12 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm transition-all duration-300",
      "placeholder:text-ink-400 focus:border-gold-500/60 focus:bg-white/10 focus:outline-none focus:ring-2 focus:ring-gold-500/20",
      "disabled:cursor-not-allowed disabled:opacity-50",
      className
    )}
    {...props}
  />
));
Input.displayName = "Input";

export { Input };
