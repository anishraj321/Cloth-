import { createContext, useContext, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

const AccordionCtx = createContext(null);

export function Accordion({ children, className }) {
  const [open, setOpen] = useState(null);
  return (
    <AccordionCtx.Provider value={{ open, setOpen }}>
      <div className={cn("divide-y divide-white/10", className)}>{children}</div>
    </AccordionCtx.Provider>
  );
}

export function AccordionItem({ value, question, children }) {
  const { open, setOpen } = useContext(AccordionCtx);
  const isOpen = open === value;
  return (
    <div>
      <button
        onClick={() => setOpen(isOpen ? null : value)}
        className="flex w-full items-center justify-between gap-4 py-5 text-left transition-colors hover:text-gold-500"
        aria-expanded={isOpen}
      >
        <span className="font-display text-lg">{question}</span>
        <motion.span
          animate={{ rotate: isOpen ? 45 : 0 }}
          transition={{ duration: 0.3 }}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-gold-500/40 text-gold-500"
        >
          <Plus size={16} />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <p className="pb-5 pr-12 text-sm leading-relaxed text-ink-300">
              {children}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
