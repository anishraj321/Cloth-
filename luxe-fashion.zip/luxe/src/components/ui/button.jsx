import { forwardRef } from "react";
import { cva } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Button — shadcn/ui style API built with class-variance-authority.
 * Variants tuned for the LUXE palette (gold, glass, outline, ghost, link).
 */
const buttonVariants = cva(
  "relative inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-medium transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-500/60 focus-visible:ring-offset-2 focus-visible:ring-offset-transparent disabled:pointer-events-none disabled:opacity-50 select-none",
  {
    variants: {
      variant: {
        gold: "bg-gold-gradient text-ink-950 font-semibold shadow-gold hover:shadow-gold-lg hover:-translate-y-0.5",
        solid:
          "bg-ink-50 text-ink-950 hover:bg-white hover:-translate-y-0.5 dark:bg-white",
        outline:
          "border border-gold-500/50 text-current hover:border-gold-500 hover:bg-gold-500/10",
        glass:
          "glass text-current hover:border-gold-500/40 hover:bg-white/10",
        ghost: "text-current hover:bg-white/10",
        link: "text-gold-500 underline-offset-4 hover:underline rounded-none",
      },
      size: {
        sm: "h-9 px-4 text-xs",
        md: "h-11 px-6",
        lg: "h-14 px-9 text-base tracking-wide",
        icon: "h-11 w-11",
      },
    },
    defaultVariants: { variant: "gold", size: "md" },
  }
);

const Button = forwardRef(
  ({ className, variant, size, asChild = false, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        {...props}
      >
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
