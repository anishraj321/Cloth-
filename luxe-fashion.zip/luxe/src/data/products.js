// -----------------------------------------------------------------------------
// LUXE product catalogue (demo data)
// Images are sourced from Unsplash (free to use). Swap the `img()` ids with your
// own CDN assets in production.
// -----------------------------------------------------------------------------

const img = (id, w = 900) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

export const SIZES = ["XS", "S", "M", "L", "XL"];

export const COLORS = [
  { name: "Obsidian", hex: "#0a0a0b" },
  { name: "Ivory", hex: "#f4f1ea" },
  { name: "Gold", hex: "#d4af37" },
  { name: "Camel", hex: "#b48a5a" },
  { name: "Slate", hex: "#5f606b" },
  { name: "Bordeaux", hex: "#5b1a24" },
];

export const products = [
  {
    id: "the-noir-trench",
    name: "The Noir Trench",
    price: 890,
    salePrice: null,
    category: "women",
    subcategory: "Outerwear",
    rating: 4.9,
    reviewsCount: 214,
    colors: [COLORS[0], COLORS[3], COLORS[4]],
    sizes: SIZES,
    tags: ["featured", "trending", "bestseller"],
    badge: "Icon",
    description:
      "A sculptural double-breasted trench cut from Italian gabardine. Cinematic drape, storm-ready, effortlessly commanding.",
    details: [
      "Water-resistant Italian gabardine",
      "Detachable storm belt",
      "Horn buttons, gold-tone hardware",
      "Tailored in Florence",
    ],
    images: [
      img("1539109136881-3be0616acf4b"),
      img("1544022613-e87ca75a784a"),
      img("1490481651871-ab68de25d43d"),
    ],
  },
  {
    id: "midnight-silk-gown",
    name: "Midnight Silk Gown",
    price: 1450,
    salePrice: 1160,
    category: "women",
    subcategory: "Eveningwear",
    rating: 5.0,
    reviewsCount: 98,
    colors: [COLORS[0], COLORS[5], COLORS[1]],
    sizes: SIZES,
    tags: ["featured", "new", "sale"],
    badge: "Sale",
    description:
      "A bias-cut mulberry silk gown that pours like liquid. Made for entrances that end conversations.",
    details: [
      "100% mulberry silk",
      "Bias-cut, floor-sweeping",
      "Hand-finished French seams",
      "Concealed side zip",
    ],
    images: [
      img("1595777457583-95e059d581b8"),
      img("1566174053879-31528523f8ae"),
      img("1572804013309-59a88b7e92f1"),
    ],
  },
  {
    id: "gold-thread-blazer",
    name: "Gold Thread Blazer",
    price: 1120,
    salePrice: null,
    category: "women",
    subcategory: "Tailoring",
    rating: 4.8,
    reviewsCount: 143,
    colors: [COLORS[0], COLORS[2]],
    sizes: SIZES,
    tags: ["new", "trending"],
    badge: "New",
    description:
      "A razor-sharp blazer woven with a whisper of real gold thread that catches the light as you move.",
    details: [
      "Virgin wool with metallic filament",
      "Structured shoulder, nipped waist",
      "Bemberg lining",
      "Functional surgeon's cuffs",
    ],
    images: [
      img("1591047139829-d91aecb6caea"),
      img("1594633312681-425c7b97ccd1"),
      img("1548624313-0396c75f8f6a"),
    ],
  },
  {
    id: "obsidian-tux",
    name: "Obsidian Evening Tuxedo",
    price: 1680,
    salePrice: null,
    category: "men",
    subcategory: "Tailoring",
    rating: 4.9,
    reviewsCount: 176,
    colors: [COLORS[0], COLORS[4]],
    sizes: SIZES,
    tags: ["featured", "bestseller"],
    badge: "Icon",
    description:
      "A peak-lapel tuxedo in deep obsidian with a satin sheen. Zero compromise black-tie perfection.",
    details: [
      "Super 120s wool",
      "Grosgrain peak lapel",
      "Half-canvas construction",
      "Matching silk bow tie included",
    ],
    images: [
      img("1594938298603-c8148c4dae35"),
      img("1507003211169-0a1dd7228f2d"),
      img("1521572163474-6864f9cf17ab"),
    ],
  },
  {
    id: "cashmere-overcoat",
    name: "Cashmere Overcoat",
    price: 1990,
    salePrice: 1592,
    category: "men",
    subcategory: "Outerwear",
    rating: 4.9,
    reviewsCount: 132,
    colors: [COLORS[3], COLORS[0], COLORS[4]],
    sizes: SIZES,
    tags: ["sale", "trending", "bestseller"],
    badge: "Sale",
    description:
      "A featherweight double-faced cashmere overcoat. The kind of warmth you feel and everyone else sees.",
    details: [
      "100% double-faced cashmere",
      "Hand-stitched edges",
      "Raglan sleeve",
      "Made in Scotland",
    ],
    images: [
      img("1608063615781-e2ef8c73d114"),
      img("1520975954732-35dd22299614"),
      img("1516257984-b1b4d707412e"),
    ],
  },
  {
    id: "ivory-cashmere-knit",
    name: "Ivory Cashmere Knit",
    price: 520,
    salePrice: null,
    category: "women",
    subcategory: "Knitwear",
    rating: 4.7,
    reviewsCount: 265,
    colors: [COLORS[1], COLORS[3], COLORS[4]],
    sizes: SIZES,
    tags: ["bestseller", "new"],
    badge: "Bestseller",
    description:
      "A cloud-soft ridged cashmere knit in warm ivory. The definition of quiet luxury.",
    details: ["Grade-A Mongolian cashmere", "Ribbed funnel neck", "Relaxed fit"],
    images: [
      img("1576566588028-4147f3842f27"),
      img("1434389677669-e08b4cac3105"),
      img("1591369822096-ffd140ec948f"),
    ],
  },
  {
    id: "leather-biker",
    name: "Sculpted Leather Biker",
    price: 1340,
    salePrice: null,
    category: "men",
    subcategory: "Outerwear",
    rating: 4.8,
    reviewsCount: 189,
    colors: [COLORS[0], COLORS[3]],
    sizes: SIZES,
    tags: ["trending", "new"],
    badge: "New",
    description:
      "Butter-soft lambskin sculpted into an asymmetric biker with gunmetal hardware. Rebel, refined.",
    details: ["Nappa lambskin", "Asymmetric zip", "Quilted shoulders", "Viscose lining"],
    images: [
      img("1551028719-00167b16eac5"),
      img("1520975916090-3105956dac38"),
      img("1512436991641-6745cdb1723f"),
    ],
  },
  {
    id: "pleated-midi",
    name: "Pleated Gold Midi",
    price: 640,
    salePrice: 448,
    category: "women",
    subcategory: "Skirts",
    rating: 4.6,
    reviewsCount: 121,
    colors: [COLORS[2], COLORS[1], COLORS[0]],
    sizes: SIZES,
    tags: ["sale", "trending"],
    badge: "Sale",
    description:
      "A liquid-gold plissé midi skirt that moves like light on water. Statement, effortless.",
    details: ["Metallic plissé", "Elasticated waist", "Midi length"],
    images: [
      img("1583496661160-fb5886a13d77"),
      img("1595341888016-a392ef81b7de"),
      img("1618932260643-eee4a2f652a6"),
    ],
  },
  {
    id: "tailored-trouser",
    name: "Sharp Tailored Trouser",
    price: 480,
    salePrice: null,
    category: "men",
    subcategory: "Tailoring",
    rating: 4.7,
    reviewsCount: 156,
    colors: [COLORS[0], COLORS[4], COLORS[3]],
    sizes: SIZES,
    tags: ["bestseller", "new"],
    badge: "Bestseller",
    description:
      "A perfectly weighted wool trouser with a knife-clean crease. Your new everyday icon.",
    details: ["Tropical wool", "Flat front", "Tapered leg", "Unfinished hem"],
    images: [
      img("1473966968600-fa801b869a1a"),
      img("1594938298603-c8148c4dae35"),
      img("1624378439575-d8705ad7ae80"),
    ],
  },
  {
    id: "satin-slip-dress",
    name: "Bordeaux Satin Slip",
    price: 560,
    salePrice: null,
    category: "women",
    subcategory: "Dresses",
    rating: 4.8,
    reviewsCount: 208,
    colors: [COLORS[5], COLORS[0], COLORS[2]],
    sizes: SIZES,
    tags: ["new", "trending", "featured"],
    badge: "New",
    description:
      "A whisper-thin satin slip in deep bordeaux with a cowl neck that catches candlelight.",
    details: ["Heavy satin", "Cowl neckline", "Adjustable straps", "Bias cut"],
    images: [
      img("1585487000160-6ebcfceb0d03"),
      img("1566479179817-c0b5b4b4b1e5"),
      img("1596783074918-c84cb06531ca"),
    ],
  },
  {
    id: "monogram-scarf",
    name: "Monogram Silk Scarf",
    price: 290,
    salePrice: 203,
    category: "women",
    subcategory: "Accessories",
    rating: 4.9,
    reviewsCount: 342,
    colors: [COLORS[2], COLORS[0], COLORS[5]],
    sizes: ["One Size"],
    tags: ["sale", "bestseller"],
    badge: "Sale",
    description:
      "A hand-rolled silk twill scarf printed with the LUXE monogram in liquid gold.",
    details: ["Silk twill", "Hand-rolled edges", '35" x 35"'],
    images: [
      img("1601924994987-69e26d50dc26"),
      img("1584917865442-de89df76afd3"),
      img("1611652022419-a9419f74343d"),
    ],
  },
  {
    id: "structured-tote",
    name: "Structured Leather Tote",
    price: 980,
    salePrice: null,
    category: "women",
    subcategory: "Accessories",
    rating: 4.8,
    reviewsCount: 187,
    colors: [COLORS[3], COLORS[0]],
    sizes: ["One Size"],
    tags: ["trending", "bestseller", "featured"],
    badge: "Icon",
    description:
      "An architectural tote in full-grain calf leather with gold feet and a suede-lined interior.",
    details: ["Full-grain calf leather", "Suede lining", "Gold-tone feet"],
    images: [
      img("1584917865442-de89df76afd3"),
      img("1590874103328-eac38a683ce7"),
      img("1548036328-c9fa89d128fa"),
    ],
  },
];

// --- Selectors -------------------------------------------------------------

export const getProductById = (id) => products.find((p) => p.id === id);

export const getByCategory = (category) =>
  products.filter((p) => p.category === category);

export const getByTag = (tag) => products.filter((p) => p.tags.includes(tag));

export const getRelated = (product, count = 4) =>
  products
    .filter((p) => p.id !== product.id && p.category === product.category)
    .slice(0, count);

export const priceRange = () => {
  const prices = products.map((p) => p.salePrice || p.price);
  return { min: Math.min(...prices), max: Math.max(...prices) };
};
