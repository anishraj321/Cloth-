const img = (id, w = 800) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

// Customer reviews / testimonials.
export const reviews = [
  {
    name: "Isabella Moreau",
    role: "Creative Director",
    avatar: img("1494790108377-be9c29b29330", 200),
    rating: 5,
    text: "The Noir Trench is the single best purchase I've made in a decade. The drape is architectural. I feel unstoppable.",
  },
  {
    name: "Julian Reyes",
    role: "Architect",
    avatar: img("1500648767791-00dcc994a43e", 200),
    rating: 5,
    text: "Fit, cloth, finishing — indistinguishable from bespoke. LUXE understands proportion better than anyone.",
  },
  {
    name: "Amara Okafor",
    role: "Gallerist",
    avatar: img("1534528741775-53994a69daeb", 200),
    rating: 5,
    text: "The Midnight Silk Gown poured over me like liquid. I've never received so many compliments in one evening.",
  },
  {
    name: "Sophie Laurent",
    role: "Editor-in-Chief",
    avatar: img("1517841905240-472988babdf9", 200),
    rating: 5,
    text: "Packaging, delivery, product — every touchpoint feels like a private atelier. This is how luxury should feel.",
  },
];

// Instagram-style gallery grid.
export const instagram = [
  img("1490481651871-ab68de25d43d", 500),
  img("1483985988355-763728e1935b", 500),
  img("1539109136881-3be0616acf4b", 500),
  img("1515886657613-9f3515b0c78f", 500),
  img("1529139574466-a303027c1d8b", 500),
  img("1487222477894-8943e31ef7b2", 500),
];

// Blog / journal posts.
export const posts = [
  {
    id: "art-of-tailoring",
    title: "The Quiet Art of Tailoring",
    excerpt:
      "Why a half-canvas construction changes everything about how a jacket lives on the body.",
    category: "Craft",
    date: "Jul 12, 2026",
    readTime: "6 min",
    author: "Isabella Moreau",
    image: img("1594938298603-c8148c4dae35"),
  },
  {
    id: "colour-of-the-season",
    title: "Bordeaux: The Colour of the Season",
    excerpt:
      "From the runways of Milan to the streets — how a single deep red is redefining evening dressing.",
    category: "Trends",
    date: "Jul 04, 2026",
    readTime: "4 min",
    author: "Sophie Laurent",
    image: img("1585487000160-6ebcfceb0d03"),
  },
  {
    id: "cashmere-guide",
    title: "A Field Guide to Cashmere",
    excerpt:
      "Grade, ply, and micron — everything you never knew you needed to know about the world's softest fibre.",
    category: "Guide",
    date: "Jun 22, 2026",
    readTime: "8 min",
    author: "Julian Reyes",
    image: img("1576566588028-4147f3842f27"),
  },
  {
    id: "gold-hour",
    title: "Dressing for the Golden Hour",
    excerpt:
      "How to wear metallics without tipping into costume — a masterclass in restraint.",
    category: "Styling",
    date: "Jun 10, 2026",
    readTime: "5 min",
    author: "Amara Okafor",
    image: img("1583496661160-fb5886a13d77"),
  },
];

// FAQ content.
export const faqs = [
  {
    category: "Orders & Shipping",
    items: [
      {
        q: "How long does delivery take?",
        a: "Complimentary express shipping arrives in 2–4 business days worldwide. Orders over $500 ship free; a flat $25 applies otherwise.",
      },
      {
        q: "Do you ship internationally?",
        a: "Yes — we deliver to over 120 countries with fully tracked, insured, carbon-neutral courier service.",
      },
      {
        q: "Can I track my order?",
        a: "Absolutely. You'll receive a live tracking link the moment your order leaves our atelier.",
      },
    ],
  },
  {
    category: "Returns & Exchanges",
    items: [
      {
        q: "What is your returns policy?",
        a: "Enjoy 30 days to return any unworn piece with tags attached for a full refund — returns are always free.",
      },
      {
        q: "How do exchanges work?",
        a: "Request an exchange from your account and we'll dispatch the new size before your original even arrives back.",
      },
    ],
  },
  {
    category: "Product & Care",
    items: [
      {
        q: "How should I care for my pieces?",
        a: "Each garment ships with a bespoke care card. As a rule, we recommend specialist dry cleaning for tailoring and cashmere.",
      },
      {
        q: "Are your materials sustainably sourced?",
        a: "Every fibre is traceable and certified. We partner exclusively with mills that meet our environmental and ethical standards.",
      },
    ],
  },
  {
    category: "Account & Payment",
    items: [
      {
        q: "Which payment methods do you accept?",
        a: "All major cards, Apple Pay, Google Pay, and interest-free instalments via our finance partners.",
      },
      {
        q: "Is checkout secure?",
        a: "Payments are processed over 256-bit TLS encryption and are fully PCI-DSS compliant. We never store card details.",
      },
    ],
  },
];
