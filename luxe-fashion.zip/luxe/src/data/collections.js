const img = (id, w = 1000) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

// Featured editorial collections shown on the home page.
export const collections = [
  {
    id: "noir",
    title: "Noir Atelier",
    subtitle: "Autumn / Winter",
    description: "Sculptural silhouettes in the deepest black.",
    image: img("1490481651871-ab68de25d43d"),
    to: "/women",
  },
  {
    id: "gilded",
    title: "The Gilded Hour",
    subtitle: "Eveningwear",
    description: "Liquid gold for moments that matter.",
    image: img("1515372039744-b8f02a3ae446"),
    to: "/categories",
  },
  {
    id: "tailored",
    title: "Sharp Tailoring",
    subtitle: "Men's Edit",
    description: "Precision cuts, uncompromising cloth.",
    image: img("1507003211169-0a1dd7228f2d"),
    to: "/men",
  },
];

// Category tiles used on the Categories page and nav.
export const categories = [
  {
    id: "outerwear",
    name: "Outerwear",
    count: 42,
    image: img("1539109136881-3be0616acf4b"),
    to: "/shop?cat=Outerwear",
  },
  {
    id: "tailoring",
    name: "Tailoring",
    count: 38,
    image: img("1594938298603-c8148c4dae35"),
    to: "/shop?cat=Tailoring",
  },
  {
    id: "eveningwear",
    name: "Eveningwear",
    count: 24,
    image: img("1595777457583-95e059d581b8"),
    to: "/shop?cat=Eveningwear",
  },
  {
    id: "knitwear",
    name: "Knitwear",
    count: 31,
    image: img("1576566588028-4147f3842f27"),
    to: "/shop?cat=Knitwear",
  },
  {
    id: "accessories",
    name: "Accessories",
    count: 56,
    image: img("1584917865442-de89df76afd3"),
    to: "/shop?cat=Accessories",
  },
  {
    id: "dresses",
    name: "Dresses",
    count: 47,
    image: img("1585487000160-6ebcfceb0d03"),
    to: "/shop?cat=Dresses",
  },
];

// Brand / press logos (text marks used as placeholders).
export const partners = ["VOGUE", "GQ", "HARPER'S", "ELLE", "W", "TATLER"];
