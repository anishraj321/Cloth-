import { createContext, useContext, useEffect, useMemo, useState } from "react";

const WishlistContext = createContext(undefined);

/** Persisted wishlist of product IDs with toggle helpers. */
export function WishlistProvider({ children }) {
  const [items, setItems] = useState(() => {
    if (typeof window === "undefined") return [];
    try {
      return JSON.parse(localStorage.getItem("luxe-wishlist") || "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("luxe-wishlist", JSON.stringify(items));
  }, [items]);

  const toggle = (id) =>
    setItems((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );

  const has = (id) => items.includes(id);
  const remove = (id) => setItems((prev) => prev.filter((x) => x !== id));
  const clear = () => setItems([]);

  const value = useMemo(
    () => ({ items, toggle, has, remove, clear, count: items.length }),
    [items]
  );

  return (
    <WishlistContext.Provider value={value}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error("useWishlist must be used within a WishlistProvider");
  return ctx;
}
