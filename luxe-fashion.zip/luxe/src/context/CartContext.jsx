import { createContext, useContext, useEffect, useMemo, useReducer, useState } from "react";

const CartContext = createContext(undefined);

/**
 * Cart line items are keyed by a composite of product id + size + color so
 * the same garment in different variants can coexist in the bag.
 */
const lineKey = (item) => `${item.id}__${item.size || "-"}__${item.color || "-"}`;

function cartReducer(state, action) {
  switch (action.type) {
    case "ADD": {
      const key = lineKey(action.payload);
      const existing = state.find((l) => l.key === key);
      if (existing) {
        return state.map((l) =>
          l.key === key ? { ...l, qty: l.qty + (action.payload.qty || 1) } : l
        );
      }
      return [...state, { ...action.payload, key, qty: action.payload.qty || 1 }];
    }
    case "REMOVE":
      return state.filter((l) => l.key !== action.payload);
    case "QTY":
      return state
        .map((l) =>
          l.key === action.payload.key
            ? { ...l, qty: Math.max(1, action.payload.qty) }
            : l
        )
        .filter((l) => l.qty > 0);
    case "CLEAR":
      return [];
    case "HYDRATE":
      return action.payload;
    default:
      return state;
  }
}

// A small library of demo coupon codes.
const COUPONS = {
  LUXE10: { type: "percent", value: 10, label: "10% off" },
  GOLD20: { type: "percent", value: 20, label: "20% off" },
  FREESHIP: { type: "shipping", value: 0, label: "Free shipping" },
};

export function CartProvider({ children }) {
  const [items, dispatch] = useReducer(cartReducer, []);
  const [coupon, setCoupon] = useState(null);
  const [hydrated, setHydrated] = useState(false);

  // Hydrate from localStorage once.
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("luxe-cart") || "[]");
      dispatch({ type: "HYDRATE", payload: saved });
      const savedCoupon = localStorage.getItem("luxe-coupon");
      if (savedCoupon && COUPONS[savedCoupon]) setCoupon(savedCoupon);
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem("luxe-cart", JSON.stringify(items));
  }, [items, hydrated]);

  useEffect(() => {
    if (coupon) localStorage.setItem("luxe-coupon", coupon);
    else localStorage.removeItem("luxe-coupon");
  }, [coupon]);

  const addItem = (product, opts = {}) =>
    dispatch({
      type: "ADD",
      payload: {
        id: product.id,
        name: product.name,
        price: product.salePrice || product.price,
        image: product.images?.[0] || product.image,
        size: opts.size,
        color: opts.color,
        qty: opts.qty || 1,
      },
    });

  const removeItem = (key) => dispatch({ type: "REMOVE", payload: key });
  const setQty = (key, qty) => dispatch({ type: "QTY", payload: { key, qty } });
  const clear = () => {
    dispatch({ type: "CLEAR" });
    setCoupon(null);
  };

  const applyCoupon = (code) => {
    const normalized = code.trim().toUpperCase();
    if (COUPONS[normalized]) {
      setCoupon(normalized);
      return { ok: true, message: `Applied: ${COUPONS[normalized].label}` };
    }
    return { ok: false, message: "Invalid coupon code" };
  };
  const removeCoupon = () => setCoupon(null);

  const totals = useMemo(() => {
    const subtotal = items.reduce((sum, l) => sum + l.price * l.qty, 0);
    const activeCoupon = coupon ? COUPONS[coupon] : null;
    const discount =
      activeCoupon?.type === "percent"
        ? (subtotal * activeCoupon.value) / 100
        : 0;
    const freeShip = activeCoupon?.type === "shipping" || subtotal - discount > 500;
    const shipping = items.length === 0 || freeShip ? 0 : 25;
    const taxable = subtotal - discount;
    const tax = Math.round(taxable * 0.08);
    const total = Math.max(0, taxable + shipping + tax);
    return { subtotal, discount, shipping, tax, total, freeShip };
  }, [items, coupon]);

  const count = items.reduce((n, l) => n + l.qty, 0);

  const value = useMemo(
    () => ({
      items,
      count,
      addItem,
      removeItem,
      setQty,
      clear,
      coupon,
      applyCoupon,
      removeCoupon,
      totals,
      availableCoupons: COUPONS,
    }),
    [items, count, coupon, totals]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}
