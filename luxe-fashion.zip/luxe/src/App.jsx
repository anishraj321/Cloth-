import { Suspense, lazy, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";

import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Preloader } from "@/components/common/Preloader";
import { CustomCursor } from "@/components/common/CustomCursor";
import { MouseGlow } from "@/components/common/MouseGlow";
import { ScrollProgress } from "@/components/common/ScrollProgress";
import { ScrollToTop } from "@/components/common/ScrollToTop";
import { PageTransition } from "@/components/common/PageTransition";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";
import { Skeleton } from "@/components/ui/skeleton";

// Eager: the landing experience. Lazy: everything else (code-splitting).
import Home from "@/pages/Home";
const Shop = lazy(() => import("@/pages/Shop"));
const Categories = lazy(() => import("@/pages/Categories"));
const Men = lazy(() => import("@/pages/Men"));
const Women = lazy(() => import("@/pages/Women"));
const NewArrivals = lazy(() => import("@/pages/NewArrivals"));
const BestSellers = lazy(() => import("@/pages/BestSellers"));
const Sale = lazy(() => import("@/pages/Sale"));
const ProductDetails = lazy(() => import("@/pages/ProductDetails"));
const Wishlist = lazy(() => import("@/pages/Wishlist"));
const Cart = lazy(() => import("@/pages/Cart"));
const Checkout = lazy(() => import("@/pages/Checkout"));
const OrderSuccess = lazy(() => import("@/pages/OrderSuccess"));
const About = lazy(() => import("@/pages/About"));
const Contact = lazy(() => import("@/pages/Contact"));
const Blog = lazy(() => import("@/pages/Blog"));
const FAQ = lazy(() => import("@/pages/FAQ"));
const NotFound = lazy(() => import("@/pages/NotFound"));
const Login = lazy(() => import("@/pages/auth/Login"));
const Register = lazy(() => import("@/pages/auth/Register"));
const ForgotPassword = lazy(() => import("@/pages/auth/ForgotPassword"));
const OTPVerification = lazy(() => import("@/pages/auth/OTPVerification"));

// Auth routes render their own full-screen stage (no navbar / footer).
const AUTH_ROUTES = ["/login", "/register", "/forgot-password", "/otp-verification"];

function PageFallback() {
  return (
    <div className="container grid min-h-screen grid-cols-1 gap-8 pt-40 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="space-y-4">
          <Skeleton className="aspect-[3/4] w-full rounded-2xl" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const isAuth = AUTH_ROUTES.includes(location.pathname);

  return (
    <>
      {loading && <Preloader onDone={() => setLoading(false)} />}

      {/* Global cinematic layers */}
      <CustomCursor />
      <MouseGlow />
      <ScrollProgress />
      <ScrollToTop />

      {!isAuth && <Navbar />}

      <AnimatePresence mode="wait">
        <ErrorBoundary key={location.pathname} fallback={<PageFallback />}>
          <Suspense fallback={<PageFallback />}>
            <PageTransition>
            <Routes location={location}>
              <Route path="/" element={<Home />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/categories" element={<Categories />} />
              <Route path="/men" element={<Men />} />
              <Route path="/women" element={<Women />} />
              <Route path="/new-arrivals" element={<NewArrivals />} />
              <Route path="/best-sellers" element={<BestSellers />} />
              <Route path="/sale" element={<Sale />} />
              <Route path="/product/:id" element={<ProductDetails />} />
              <Route path="/wishlist" element={<Wishlist />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/order-success" element={<OrderSuccess />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/otp-verification" element={<OTPVerification />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
            </PageTransition>
          </Suspense>
        </ErrorBoundary>
      </AnimatePresence>

      {!isAuth && <Footer />}
    </>
  );
}
