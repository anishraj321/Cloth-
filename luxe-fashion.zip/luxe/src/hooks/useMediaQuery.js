import { useEffect, useState } from "react";

/** Reactively track a CSS media query (SSR-safe). */
export function useMediaQuery(query) {
  const [matches, setMatches] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia(query).matches;
  });

  useEffect(() => {
    const mql = window.matchMedia(query);
    const handler = (e) => setMatches(e.matches);
    setMatches(mql.matches);
    mql.addEventListener("change", handler);
    return () => mql.removeEventListener("change", handler);
  }, [query]);

  return matches;
}

/** Convenience: true when the pointer is a precise device capable of hover. */
export const useHasFinePointer = () =>
  useMediaQuery("(hover: hover) and (pointer: fine)");

/** Convenience: true when the user prefers reduced motion. */
export const usePrefersReducedMotion = () =>
  useMediaQuery("(prefers-reduced-motion: reduce)");
