import { useCallback, useEffect, useState } from "react";

const KEY = "luxe-recently-viewed";
const MAX = 8;

/** Track the last few products a visitor viewed, persisted to localStorage. */
export function useRecentlyViewed() {
  const [ids, setIds] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(KEY) || "[]");
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(ids));
  }, [ids]);

  const record = useCallback((id) => {
    setIds((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, MAX));
  }, []);

  return { ids, record };
}
